<?php
    $conn = new mysqli("localhost","root","","biblioteka");
?>

<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Biblioteka</title>
        <link rel="stylesheet" href="styl.css">
    </head>
    <body>
        <header>
            <h1>Miejsca Biblioteka Publiczna w Książkowicach</h1>
        </header>

        <div id="lewy">
            <img src="biblioteka.png" alt="książki">
            <h3>ul. czytelnicza 25<br>12-120 Książkowice<br>tel.: 555666777<br>e-mail: <a href="mailto:biuro@biblioteka.pl">biuro@biblioteka.pl</a></h3>
        </div>

        <div id="srodkowy">
            <h2>Dodaj nowego czytelnika</h2>
            <form action="biblioteka.php" method="post">
                <label for="imie">imię: </label><input type="text" name="imie" id="imie"><br>
                <label for="nazwisko">nazwisko: </label><input type="text" name="nazwisko" id="nazwisko"><br>
                <label for="rok">rok urodzenia: </label><input type="number" name="rok" id="rok"><br>
                <button type="submit">DODAJ</button>
            </form>
            <?php
                // Skrypt #2
                if(isset($_POST["imie"]) && isset($_POST["nazwisko"]) && isset($_POST["rok"])) {
                    $imie = $_POST["imie"];
                    $nazwisko = $_POST["nazwisko"];
                    $rok = $_POST["rok"];
                    $kod = strtoupper(substr($imie, 0, 2).substr($nazwisko, 0, 2).substr($rok, -2));

                    $sql = "INSERT INTO czytelnicy (imie, nazwisko, kod) VALUES('$imie', '$nazwisko', '$kod');";
                    $result = $conn->query($sql);

                    echo "Czytelnik: $imie $nazwisko został dodany do bazy danych";
                }
            ?>
        </div>

        <div id="prawy">
            <h2>W naszych zbiorach znajdziesz dzieła następujących autorów:</h2>
            <ol>
                <?php
                    // Skrypt #1
                    $sql = "SELECT imie, nazwisko FROM autorzy;";
                    $result = $conn->query($sql);

                    while($row = $result -> fetch_array()) {
                        echo "<li>".$row["imie"]." ".$row["nazwisko"]."</li>";
                    }
                ?>
            </ol>
        </div>

        <footer>
            <p>Projekt strony: <a href="https://ee-informatyk.pl/" target="_blank" style="color: unset;text-decoration: none;">EE-Informatyk.pl</a></p>
        </footer>
    </body>
</html>

<?php
    $conn -> close();
?>