<?php
    $conn = new mysqli("localhost","root","","dane2");
?>

<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Grzybobranie</title>
        <link rel="stylesheet" href="styl5.css">
    </head>
    <body>
        <div id="logo">
            <a href="borowik.jpg"><img src="borowik-miniatura.jpg" alt="Grzybobranie"></a>
        </div>

        <div id="tytul">
            <h1>Idziemy na grzyby!</h1>
        </div>

        <div id="lewy">
            <?php
                // Skrypt #1
                $sql = "SELECT nazwa_pliku, potoczna FROM grzyby;";
                $result = $conn->query($sql);
                
                while($row = $result -> fetch_array()) {
                    echo "<img src='".$row["nazwa_pliku"]."' alt='".$row["potoczna"]."' title='".$row["potoczna"]."'>";
                }
            ?>
        </div>

        <div id="prawy">
            <h2>Grzyby jadalne</h2>
            <?php
                // Skrypt #2
                $sql = "SELECT nazwa, potoczna FROM grzyby WHERE jadalny = 1;";
                $result = $conn->query($sql);
                
                while($row = $result -> fetch_array()) {
                    echo "<p>".$row["nazwa"]." (".$row["potoczna"].")</p>";
                }
            ?>
            <h2>Polecamy do sosów</h2>
            <?php
                // Skrypt #3
                $sql = "SELECT grzyby.nazwa, grzyby.potoczna, rodzina.nazwa FROM grzyby, rodzina, potrawy WHERE grzyby.rodzina_id = rodzina.id AND grzyby.potrawy_id = potrawy.id AND potrawy.nazwa = 'sos';";
                $result = $conn->query($sql);
                
                echo "<ol>";
                while($row = $result -> fetch_array()) {
                    echo "<li>".$row[0]." (".$row[1].") rodzina: ".$row[2]."</li>";
                }
                echo "</ol>";
            ?>
        </div>

        <footer>
            <p>Autor: <a href="https://ee-informatyk.pl/" target="_blank" style="color: orange; text-decoration: none;">EE-Informatyk.pl</a></p>
        </footer>
    </body>
</html>

<?php
    $conn -> close();
?>