function zamowienie() {
    let ksztalt = document.getElementById("ksztalt").value;
    let r = document.getElementById("r").value;
    let g = document.getElementById("g").value;
    let b = document.getElementById("b").value;

    let wynik = document.getElementById("wynik");

    let kolor = document.getElementById("kolor");

    let wybranyKsztalt = "";

    if (ksztalt == 1){
        wybranyKsztalt = "miś";
    }
    else if (ksztalt == 2){
        wybranyKsztalt = "żabka";
    }
    else if (ksztalt == 3){
        wybranyKsztalt = "serce";
    }
    else {
        wybranyKsztalt = "inny kształt";
    }

    wynik.innerText = `Zamówiłeś żelka: ${wybranyKsztalt}`;

    kolor.style.backgroundColor = `rgb(${r}, ${g}, ${b})`;
}