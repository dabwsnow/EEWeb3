<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Rzut oszczepem</title>
        <link rel="stylesheet" href="styl_oszczep.css">
    </head>
    <body>
        <header>
            <h1>Klub sportowy: rzut oszczepem</h1>
        </header>

        <main>
            <?php
                // Skrypt #1
                $conn = new mysqli("localhost","root","","sportowcy");

                $sql = "SELECT MAX(wynik) FROM wyniki WHERE dyscyplina_id = 3;";
                $result = $conn->query($sql);

                while($row = $result -> fetch_array()) {
                    echo "<h1>Nasz rekord: ".$row[0]." m</h1>";
                }

                $sql = "SELECT COUNT(id) FROM sportowiec;";
                $result = $conn->query($sql);

                while($row = $result -> fetch_row()) {
                    $liczba_rekordow = $row[0];
                }

                $liczba_kolumn = 2;
                $liczba_wierszy = ceil($liczba_rekordow/$liczba_kolumn);
                
                echo "<table>";

                $id = 0;
                for ($i=0; $i < $liczba_wierszy; $i++) {
                    echo "<tr>";
                    for ($j=0; $j < $liczba_kolumn; $j++) {
                        $id++;
                        if($i*$liczba_kolumn+$j < $liczba_rekordow) {
                            echo "<td>";
                            
                                $sql = "SELECT imie, nazwisko FROM sportowiec WHERE id=$id;";
                                $result = $conn->query($sql);
                                
                                while($row = $result -> fetch_array()) {
                                    echo "<h3>".$row["imie"]." ".$row["nazwisko"]."</h3>";
                                }

                                $sql = "SELECT AVG(wynik) FROM wyniki WHERE dyscyplina_id = 3 AND sportowiec_id = $id;";
                                $result = $conn->query($sql);
                                
                                while($row = $result -> fetch_array()) {
                                    echo "<p>średni wynik: ".$row[0]."</p>";
                                }

                            echo "</td>";
                        }
                    }
                    echo "</tr>";
                }

                echo "</table>";

                $conn -> close();
            ?>
        </main>

        <footer>
            <p>Klub sportowy</p>
            Stronę opracował: <a href="https://ee-informatyk.pl/" target="_blank" style="color: unset;text-decoration: none;">EE-Informatyk.pl</a>
        </footer>
    </body>
</html>