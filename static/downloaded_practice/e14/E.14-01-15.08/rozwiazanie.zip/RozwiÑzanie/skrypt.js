function pole() {
    var dlugosc = document.getElementById("dlugosc").value;
    var wynikElem = document.getElementById("wynik");
    if (dlugosc == "" || isNaN(dlugosc)) {
        wynikElem.innerHTML = "Należy wpisać wartość liczbową";
    }
    else {
        var pole = dlugosc ** 2;
        wynikElem.innerHTML = "Pole kwadratu o boku " + dlugosc + " wynosi: " + pole;
    }
}

function obwod() {
    var dlugosc = document.getElementById("dlugosc").value;
    var wynikElem = document.getElementById("wynik");
    if (dlugosc == "" || isNaN(dlugosc)) {
        wynikElem.innerHTML = "Należy wpisać wartość liczbową";
    }
    else {
        var obwod = 4 * dlugosc;
        wynikElem.innerHTML = "Obwód kwadratu o boku " + dlugosc + " wynosi: " + obwod;
    }
}