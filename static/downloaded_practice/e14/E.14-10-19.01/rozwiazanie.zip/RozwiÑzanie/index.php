<?php
    $conn = new mysqli("localhost","root","","baza");
?>

<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Odżywianie zwierząt</title>
        <link rel="stylesheet" href="styl4.css">
    </head>
    <body>
        <header>
            <h2>DRAPIEŻNIKI I INNE</h2>
        </header>

        <div id="formularz">
            <h3>Wybierz styl życia:</h3>
            <form action="index.php" method="post">
                <select name="styl" id="styl">
                    <option value="drapieznik">Drapieżniki</option>
                    <option value="roslinozerny">Roślinożerne</option>
                    <option value="padlinozerny">Padlinożerne</option>
                    <option value="wszystkozerny">Wszystkożerne</option>
                </select>
                <button type="submit">Zobacz</button>
            </form>
        </div>

        <div id="lewy">
            <h3>Lista zwierząt</h3>
            <?php
                // Skrypt #1
                $sql = "SELECT zwierzeta.gatunek, odzywianie.rodzaj FROM zwierzeta, odzywianie WHERE zwierzeta.Odzywianie_id = odzywianie.id";
                $result = $conn->query($sql);

                echo "<ul>";
                while($row = $result -> fetch_array()) {
                    echo "<li>".$row[0]." -> ".$row[1]."</li>";
                }
                echo "</ul>";
            ?>
        </div>

        <div id="srodkowy">
            <?php
                // Skrypt #2
                if(isset($_POST["styl"])) {
                    $styl = $_POST["styl"];

                    if($styl == "drapieznik") {
                        echo "<h3>Drapieżniki</h3>";
                    }
                    else if($styl == "roslinozerny") {
                        echo "<h3>Roślinożerne</h3>";
                    }
                    else if($styl == "padlinozerny") {
                        echo "<h3>Padlinożerne</h3>";
                    }
                    else if($styl == "wszystkozerny") {
                        echo "<h3>Wszystkożerne</h3>";
                    }

                    $sql2 = "SELECT zwierzeta.id, zwierzeta.gatunek, zwierzeta.wystepowanie FROM zwierzeta, odzywianie WHERE zwierzeta.Odzywianie_id = odzywianie.id AND odzywianie.rodzaj = '$styl';";
                    $result2 = $conn->query($sql2);
    
                    while($row2 = $result2 -> fetch_array()) {
                        echo $row2[0].". ".$row2[1]." ".$row2[2]."<br>";
                    }
                }
            ?>
        </div>

        <div id="prawy">
            <img src="drapieznik.jpg" alt="Wilki">
        </div>

        <footer>
            <a href="https://pl.wikipedia.org" target="_blank">Poczytaj o zwierzętach na Wikipedii</a>, autor strony: <a href="https://ee-informatyk.pl/" target="_blank" style="color: #fff;">EE-Informatyk.pl</a>
        </footer>
    </body>
</html>

<?php
    $conn -> close();
?>