<?php
    $conn = new mysqli("localhost","root","","grzybobranie");
?>

<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Grzybobranie</title>
        <link rel="stylesheet" href="styl.css">
    </head>
    <body>
        <div id="tytul">
            <h1>Czas na grzyby!</h1>
        </div>

        <div id="logo">
            <a href="podgrzybek.jpg"><img src="podgrzybek-miniatura.jpg" alt="Grzybobranie"></a>
        </div>

        <div id="lewy">
            <h3>Grzyby jadalne</h3>
            <?php
                // Skrypt #1
                $sql = "SELECT id, nazwa, potoczna FROM grzyby WHERE jadalny = 1;";
                $result = $conn->query($sql);

                while($row = $result -> fetch_array()) {
                    echo "<p>".$row["id"].". ".$row["nazwa"]." (".$row["potoczna"].")</p>";
                }
            ?>
            <h3>Polecamy do zup</h3>
            <ol>
                <?php
                    // Skrypt #2
                    $sql = "SELECT grzyby.potoczna, rodzina.nazwa FROM grzyby INNER JOIN rodzina ON grzyby.rodzina_id = rodzina.id WHERE grzyby.potrawy_id = 4;";
                    $result = $conn->query($sql);

                    while($row = $result -> fetch_array()) {
                        echo "<li>".$row[0].", rodzina: ".$row[1]."</li>";
                    }
                ?>
            </ol>
        </div>

        <div id="prawy">
            <?php
                // Skrypt #3
                $sql = "SELECT nazwa_pliku, nazwa FROM grzyby;";
                $result = $conn->query($sql);

                while($row = $result -> fetch_array()) {
                    echo "<img src='".$row["nazwa_pliku"]."' title='".$row["nazwa"]."' alt='".$row["nazwa"]."'>";
                }
            ?>
        </div>

        <footer>
            <p>Autor: <a href="https://ee-informatyk.pl/" target="_blank" style="color: unset;text-decoration: none;">EE-Informatyk.pl</a></p>
        </footer>
    </body>
</html>

<?php
    $conn -> close();
?>