function kalkulacja() {
    let liczba = document.getElementById("liczba").value;
    let klient = document.getElementById("klient").checked;
    let koszt;

    if (liczba <= 40) {
        koszt = liczba * 3;
    } else {
        koszt = liczba * 2;
    }

    if (klient) {
        koszt -= liczba * 0.3;
    }

    document.getElementById("wynik").innerHTML = "Twoje ogłoszenia będą kosztować: " + koszt + " PLN";
}