<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sklep muzyczny</title>
        <link rel="stylesheet" href="muzyka.css">
    </head>
    <body>
        <header>
            <h1>SKLEP MUZYCZNY</h1>
        </header>

        <div id="lewy">
            <h2>NASZA OFERTA</h2>
            <ol>
                <li>Instrumenty muzyczne</li>
                <li>Sprzęt audio</li>
                <li>Płyty CD</li>
            </ol>
        </div>

        <div id="prawy">
            <h2>FORMULARZ REJESTRACYJNY</h2>
            <?php
                // Skrypt #1
                if(isset($_POST["imie"])) {
                    $imie = $_POST["imie"];
                    $nazwisko = $_POST["nazwisko"];
                    $adres = $_POST["adres"];
                    $telefon = $_POST["telefon"];
                    $login = $_POST["login"];
                    $haslo = $_POST["haslo"];


                    $conn = new mysqli("localhost","root","","sklep");

                    $sql = "INSERT INTO uzytkownicy VALUES (NULL, '$imie','$nazwisko','$adres','$telefon');";
                    $result = $conn->query($sql);

                    $sql2 = "INSERT INTO konta VALUES (NULL, '$login', '$haslo');";
                    $result2 = $conn->query($sql2);

                    $conn -> close();

                    echo "Konto $imie $nazwisko zostało zarejestrowane w sklepie muzycznym";
                }
            ?>
        </div>
    </body>
</html>