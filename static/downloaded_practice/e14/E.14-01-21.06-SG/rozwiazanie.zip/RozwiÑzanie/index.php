<?php
    $conn = new mysqli("localhost","root","","sklep");
?>

<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Artykuły papiernicze</title>
        <link rel="stylesheet" href="styl.css">
    </head>
    <body>
        <header>
            <h1>W naszym sklepie internetowym kupisz najtaniej</h1>
        </header>

        <div id="lewy">
            <h2>Kontakt</h2>
            <p>telefon: 444333222<br>e-mail: <a href="mailto:bok@sklep.pl">bok@sklep.pl</a></p>
            <img src="promocja2.png" alt="promocja">
        </div>

        <div id="srodkowy">
            <h2>Promocja 10% obejmuje artykuły:</h2>
            <ul>
                <?php
                    // Skrypt #1
                    $sql = "SELECT nazwa FROM towary WHERE promocja = 1;";
                    $result = $conn->query($sql);

                    while($row = $result -> fetch_array()) {
                        echo "<li>".$row["nazwa"]."</li>";
                    }
                ?>
            </ul>
        </div>

        <div id="prawy">
            <h2>Cena wybranego artykułu w promocji</h2>
            <form action="index.php" method="post">
                <select name="lista" id="lista">
                    <option value="Gumka do mazania">Gumka do mazania</option>
                    <option value="Cienkopis">Cienkopis</option>
                    <option value="Pisaki 60 szt.">Pisaki 60 szt.</option>
                    <option value="Markery 4 szt.">Markery 4 szt.</option>
                </select>
                <button type="submit">WYBIERZ</button>
            </form>
            <?php
                // Skrypt #2
                if(isset($_POST["lista"])) {
                    $lista = $_POST["lista"];
                    $sql = "SELECT cena FROM towary WHERE nazwa = '$lista';";
                    $result = $conn->query($sql);

                    while($row = $result -> fetch_array()) {
                        $cena = $row["cena"];
                        $cena = $cena * 0.9;
                        $cena = number_format($cena, 2);

                        echo "$lista kosztuje po przecenie $cena";
                    }
                }
            ?>
        </div>

        <footer>
            <h3>Autor strony <a href="https://ee-informatyk.pl/" target="_blank" style="color: unset;text-decoration: none;">EE-Informatyk.pl</a></h3>
        </footer>
    </body>
</html>

<?php
    $conn -> close();
?>