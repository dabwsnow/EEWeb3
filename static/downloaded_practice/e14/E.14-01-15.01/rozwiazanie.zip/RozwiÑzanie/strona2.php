<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Potęgowanie</title>
    </head>
    <body>
        <header>
            <a href="index.html"><img src="baner.jpg" alt="baner"></a>
        </header>

        <nav>
            <br>Menu<br>
            - <a href="strona1.html">proste działania</a><br>
            - <a href="strona2.php">potęgowanie</a>
        </nav>

        <main>
            <h1>POTĘGOWANIE</h1>
            <form action="strona2.php" method="post">
                <label for="podstawa"><i>Podaj podstawę potęgi:</i></label> <input type="number" name="podstawa" id="podstawa"><br><br>
                <label for="wykladnik"><i>Podaj dodatni, całkowity wykładnik potęgi:</i></label> <input type="number" name="wykladnik" id="wykladnik"><br><br>
                <button type="submit">POTĘGOWANIE</button>
            </form>
            <br>

            <?php
                if(isset($_POST["podstawa"]) && isset($_POST["wykladnik"])) {
                    $podstawa = $_POST["podstawa"];
                    $wykladnik = $_POST["wykladnik"];
                    if($wykladnik != 0) {
                        if(!empty($podstawa) && !empty($wykladnik)) {
                            if($wykladnik > 0) {
                                $wynik = pow($podstawa, $wykladnik);
                                echo "Wynik działania wynosi: $wynik";
                            }
                            else {
                                echo "Wykładnik potęgi musi być dodatni";
                            }
                        }
                        else {
                            echo "Wpisz podstawę i wykładnik potęgi.";
                            
                        }
                    }
                    else {
                        echo "Wynik działania wynosi: 1";
                    }
                }
            ?>
        </main>
    </body>
</html>