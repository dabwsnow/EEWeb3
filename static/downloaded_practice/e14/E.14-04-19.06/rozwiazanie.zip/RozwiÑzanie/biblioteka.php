<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Biblioteka publiczna</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <header>
            <h2>Miejska Biblioteka Publiczna w Książkowicach</h2>
        </header>

        <div id="lewy">
            <h2>Dodaj czytelnika</h2>
            <form action="biblioteka.php" method="post">
                imię: <input type="text" name="imie" id="imie"><br>
                nazwisko: <input type="text" name="nazwisko" id="nazwisko"><br>
                rok urodzenia: <input type="number" name="rok" id="rok"><br>
                <button type="submit">DODAJ</button>
            </form>
            <?php
                // Skrypt #1
                if(isset($_POST["imie"]) && isset($_POST["nazwisko"]) && isset($_POST["rok"])) {
                    $imie = $_POST["imie"];
                    $nazwisko = $_POST["nazwisko"];
                    $rok = $_POST["rok"];
                    $kod = strtolower(substr($imie, 0, 2) . substr($rok, -2) . substr($nazwisko, 0, 2));


                    $conn = new mysqli("localhost","root","","biblioteka");

                    $sql = "INSERT INTO czytelnicy VALUES (NULL, '$imie', '$nazwisko', '$kod');";
                    $result = $conn->query($sql);

                    $conn -> close();

                    echo "Czytelnik: $nazwisko został dodany do bazy danych";
                }
            ?>
        </div>

        <div id="srodkowy">
            <img src="biblioteka.png" alt="biblioteka">
            <h4>ul. Czytelnicza 25<br>12-120 Książkowice<br>tel.: 123123123<br>e-mail: <a href="mailto:biuro@bib.pl">biuro@bib.pl</a></h4>
        </div>

        <div id="prawy">
            <h3>Nasi czytelnicy: </h3>
            <?php
                // Skrypt #2 
                $conn = new mysqli("localhost","root","","biblioteka");

                $sql = "SELECT imie, nazwisko FROM czytelnicy;";
                $result = $conn->query($sql);

                echo "<ul>";
                while($row = $result -> fetch_array()) {
                    echo "<li>".$row["imie"]." ".$row["nazwisko"]."</li>";
                }
                echo "</ul>";

                $conn -> close();
            ?>
            
        </div>

        <footer>
            <p>Projekt witryny: <a href="https://ee-informatyk.pl/" target="_blank" style="color: #000;text-decoration: none;">EE-Informatyk.pl</a></p>
        </footer>
    </body>
</html>