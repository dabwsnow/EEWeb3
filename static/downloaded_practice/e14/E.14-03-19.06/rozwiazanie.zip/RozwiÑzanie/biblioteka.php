<?php
    $conn = new mysqli("localhost","root","","biblioteka");
?>

<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Biblioteka miejska</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <header>
            <h2>Miejska Biblioteka Publiczna w Książkowicach</h2>
        </header>

        <div id="lewy">
            <h3>W naszych zbiorach znajdziesz dzieła następujących autorów:</h3>
            <?php
                // Skrypt #1
                
                $sql = "SELECT imie, nazwisko FROM autorzy;";
                $result = $conn->query($sql);

                echo "<ul>";
                while($row = $result -> fetch_array()) {
                    echo "<li>".$row["imie"]." ".$row["nazwisko"]."</li>";
                }
                echo "</ul>";
            ?>
            
        </div>

        <div id="srodkowy">
            <h3>Dodaj nowego czytelnika</h3>
            <form action="biblioteka.php" method="post">
                imię: <input type="text" name="imie" id="imie"><br>
                nazwisko: <input type="text" name="nazwisko" id="nazwisko"><br>
                rok urodzenia: <input type="number" name="rok" id="rok"><br>
                <button type="submit">DODAJ</button>
            </form>
            <?php
                // Skrypt #2
                if(isset($_POST["imie"]) && isset($_POST["nazwisko"]) && isset($_POST["rok"])) {
                    $imie = $_POST["imie"];
                    $nazwisko = $_POST["nazwisko"];
                    $rok = $_POST["rok"];

                    $kod = strtoupper(substr($imie, 0, 2)) . strtoupper(substr($nazwisko, 0, 2)) . substr($rok, -2);

                    $sql = "INSERT INTO czytelnicy VALUES (NULL, '$imie', '$nazwisko', '$kod');";
                    $result = $conn->query($sql);

                    echo "Czytelnik: $imie $nazwisko został dodany do bazy danych";
                }
            ?>
        </div>

        <div id="prawy">
            <img src="biblioteka.png" alt="książki">
            <h4>ul. Czytelnicza 25<br>12-120 Książkowice<br>tel.: 123123123<br>e-mail: <a href="mailto:biuro@biblioteka.pl">biuro@biblioteka.pl</a></h4>
        </div>

        <footer>
            <p>Projekt strony: <a href="https://ee-informatyk.pl/" target="_blank" style="color: #000;text-decoration: none;">EE-Informatyk.pl</a></p>
        </footer>
    </body>
</html>

<?php
    $conn -> close();
?>