<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Hurtownia komputerowa</title>
        <link rel="stylesheet" href="styl2.css">
    </head>
    <body>
        <div id="lista">
            <ul>
                <li>Producenci</li>
                <ol>
                    <li>Intel</li>
                    <li>AMD</li>
                    <li>Motorola</li>
                    <li>Corsair</li>
                    <li>ADATA</li>
                    <li>WD</li>
                    <li>Kingstone</li>
                    <li>Patriot</li>
                    <li>Asus</li>
                </ol>
            </ul>
        </div>

        <div id="formularz">
            <h1>Dystrybucja sprzętu komputerowego</h1>
            <form action="hurtownia.php" method="post">
                Wybierz producenta<br>
                <input type="number" name="id" id="id"> <button type="submit">WYŚWIETL</button>
            </form>
        </div>

        <div id="logo">
            <img src="sprzet.png" alt="Sprzedajemy komputery">
        </div>

        <div id="glowny">
            <h2>Podzespoły wybranego producenta</h2>
            <?php
                // Skrypt #1
                if(isset($_POST["id"])) {
                    $id = $_POST["id"];

                    $conn = new mysqli("localhost","root","","sklep");

                    $sql = "SELECT podzespoly.nazwa, podzespoly.dostepnosc, podzespoly.cena FROM podzespoly, producenci WHERE podzespoly.producenci_id = producenci.id AND producenci_id = $id;";
                    $result = $conn->query($sql);
    
                    while($row = $result -> fetch_array()) {
                        if($row[1] > 0) {
                            $dostepnosc = "DOSTĘPNY";
                        }
                        else {
                            $dostepnosc = "NIEDOSTĘPNY";
                        }
                        echo "<p>".$row[0]." Cena: ".$row[2]." ".$dostepnosc."</p>";
                    }
    
                    $conn -> close();
                }
                else {
                    echo "<p>Wybierz producenta</p>";
                }
            ?>
        </div>

        <footer>
            <h4>Zapraszamy od poniedziałku do soboty w godzinach 7<sup>30</sup>-16<sup>30</sup></h4>
            Strony partnerów: <a href="http://adata.pl/" target="_blank">ADATA</a> <a href="http://patrio.pl/" target="_blank">Patriot</a> <a href="mailto:biuro@hurt.pl">Napisz</a><br><br>
            <p>Stronę wykonał: <a href="https://ee-informatyk.pl/" target="_blank">EE-Informatyk.pl</a></p>
        </footer>
    </body>
</html>