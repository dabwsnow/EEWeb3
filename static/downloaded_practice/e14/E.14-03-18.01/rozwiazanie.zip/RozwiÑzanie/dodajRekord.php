<?php

    if(isset($_POST["kategoria"])) {
        $kategoria = $_POST["kategoria"];
        $podkategoria = $_POST["podkategoria"];
        $tytul = $_POST["tytul"];
        $tresc = $_POST["tresc"];

        $conn = new mysqli("localhost","root","","ogloszenia");

        $sql = "INSERT INTO ogloszenie (uzytkownik_id, kategoria, podkategoria, tytul, tresc) VALUES (1, $kategoria, $podkategoria, '$tytul', '$tresc');";
        $result = $conn->query($sql);
        
        $conn -> close();

        echo "Ogłoszenie pomyślnie dodane";
    }
?>