<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Salon pielęgnacji</title>
        <link rel="stylesheet" href="salon.css">
    </head>
    <body>
        <header>
            <h1>SALON PIELĘGNACJI PSÓW I KOTÓW</h1>
        </header>

        <div id="lewy">
            <h3>SALON ZAPRASZA W DNIACH</h3>
            <ul>
                <li>Poniedziałek, 12:00 - 18:00</li>
                <li>Wtorek, 12:00 - 18:00</li>
            </ul>
            <a href="pies.jpeg"><img src="pies-mini.jpg" alt="Pies"></a>
            <p>Umów się telefonicznie na wizytę lub po prostu przyjdź!</p>
        </div>

        <div id="srodkowy">
            <h3>PRZYPOMNIENIE O NASTĘPNEJ WIZYCIE</h3>
            <?php
                // skrypt #1
                $conn = new mysqli("localhost","root","","salon");

                $sql = "SELECT imie,rodzaj,nastepna_wizyta,telefon FROM zwierzeta WHERE nastepna_wizyta != 0;";
                $result = $conn->query($sql);

                while($row = $result -> fetch_array()) {
                    if($row["rodzaj"] == 1) {
                        $rodzaj = "Pies";
                    }
                    else {
                        $rodzaj = "Kot";
                    }
                    echo "$rodzaj: ".$row["imie"]."<br>";
                    echo "Data następnej wizyty: ".$row["nastepna_wizyta"].", telefon właściciela: ".$row["telefon"]."<br>";
                }

                $conn -> close();
            ?>
        </div>

        <div id="prawy">
            <h3>USŁUGI</h3>
            <?php
                // skrypt #2
                $conn = new mysqli("localhost","root","","salon");

                $sql = "SELECT nazwa,cena FROM uslugi;";
                $result = $conn->query($sql);

                while($row = $result -> fetch_array()) {
                    echo $row["nazwa"].", ".$row["cena"]."<br>";
                }

                $conn -> close();
            ?>
        </div>
    </body>
</html>