<?php
    if(isset($_POST["data"])) {
        $data = $_POST["data"];
        $osoby = $_POST["osoby"];
        $telefon = $_POST["telefon"];

        $conn = new mysqli("localhost","root","","baza");

        $sql = "INSERT INTO rezerwacje VALUES (NULL, NULL, '$data', $osoby, '$telefon');";
        $result = $conn->query($sql);

        $conn -> close();


        echo "Dodano rezerwację do bazy";
    }
?>