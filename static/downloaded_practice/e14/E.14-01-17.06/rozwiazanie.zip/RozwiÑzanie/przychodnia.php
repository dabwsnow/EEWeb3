<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Przychodnia</title>
        <link rel="stylesheet" href="przychodnia.css">
    </head>
    <body>
        <header>
            <h1>PRAKTYKA LEKARZA RODZINNEGO</h1>
        </header>

        <div id="lewy">
            <h3>LISTA PACJENTÓW</h3>
            <?php
                // Skrypt #1
                $conn = new mysqli("localhost","root","","przychodnia");

                $sql = "SELECT id,imie,nazwisko FROM Pacjenci;";
                $result = $conn->query($sql);

                while($row = $result -> fetch_array()) {
                    echo $row["id"]." ".$row["imie"]." ".$row["nazwisko"]."<br>";
                }

                $conn -> close();
            ?>

            <br><br>

            <form action="pacjent.php" method="post">
                Podaj id:<br>
                <input type="number" name="id" id="id">
                <button type="submit">Pokaż dane</button>
            </form>

            <h3>LEKARZE</h3>
            <ul>
                <li>pn - śr</li>
                    <ol>
                        <li>Anna Kwiatkowska</li>
                        <li>Jan Kowalewski</li>
                    </ol>
                <li>czw - pt</li>
                    <ol>
                        <li>Krzysztof Nowak</li>
                    </ol>
            </ul>
        </div>

        <div id="prawy">
            <h2>INFORMACJE SZCZEGÓŁOWE O PACJENCIE</h2>
            <p>Brak wybranego pacjenta</p>
        </div>

        <footer>
            <p>utworzone przez: <a href="https://ee-informatyk.pl/" target="_blank">EE-Informatyk.pl</a></p>
            <a href="kwerendy.txt">Pobierz plik z kwerendami</a>
        </footer>
    </body>
</html>