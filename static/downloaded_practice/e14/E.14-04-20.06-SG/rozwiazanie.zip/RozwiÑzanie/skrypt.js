function cena(cena){
    document.getElementById('wynik').innerHTML = 'Wybrałeś ozdobę. Cena: ' + cena;
}