<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sklep</title>
        <link rel="stylesheet" href="styl.css">
    </head>
    <body>
        <header>
            <h1>Ozdoby - sklep</h1>
        </header>

        <div id="lewy">
            <h2>OZDOBY</h2>
            <a href="galeria.html">Galeria</a><br>
            <a href="zamowienie.php">Zamówienie</a>
        </div>

        <div id="srodkowy">
            <p>Dodaj użytkownika</p>
            <form action="zamowienie.php" method="post">
                <label for="imie">Imię:</label> <input type="text" name="imie" id="imie"><br>
                <label for="nazwisko">Nazwisko:</label> <input type="text" name="nazwisko" id="nazwisko"><br>
                <label for="email">e-mail:</label> <input type="email" name="email" id="email"><br>
                <button type="submit">WYŚLIJ</button>
            </form>

            <?php
                if(isset($_POST["imie"]) && isset($_POST["nazwisko"]) && isset($_POST["email"])) {
                    $imie = $_POST["imie"];
                    $nazwisko = $_POST["nazwisko"];
                    $email = $_POST["email"];

                    $conn = new mysqli("localhost","root","","sklep");

                    $sql = "SELECT count(id) FROM zamowienia;";
                    $result = $conn->query($sql);
                    
                    while($row = $result -> fetch_array()) {
                        $id = $row[0];
                    }

                    $id++;

                    $sql = "INSERT INTO zamowienia VALUES ($id, '$imie', '$nazwisko', '$email', NULL, NULL, NULL, NULL);";
                    $result = $conn->query($sql);
    
                    $conn -> close();

                    echo "Pomyślnie dodano użytkownika";
                }
            ?>
        </div>

        <div id="prawy">
            <img src="animacja.gif" alt="Animacja">
        </div>

        <footer>
            <h3>Autor strony: <a href="https://ee-informatyk.pl/" target="_blank" style="color: unset;text-decoration: none;">EE-Informatyk.pl</a></h3>
        </footer>
    </body>
</html>