<?php
    $conn = new mysqli("localhost","root","","baza");
?>

<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Gromady kręgowców</title>
        <link rel="stylesheet" href="style12.css">
    </head>
    <body>
        <div id="menu">
            <a href="gromada-ryby.html">gromada ryb</a>
            <a href="gromada-ptaki.html">gromada ptaków</a>
            <a href="gromada-ssaki.html">gromada ssaków</a>
        </div>

        <div id="logo">
            <h2>GROMADY KRĘGOWCÓW</h2>
        </div>

        <div id="lewy">
            <?php
                // Skrypt #1
                $sql = "SELECT id, Gromady_id, gatunek, wystepowanie FROM zwierzeta WHERE Gromady_id IN (4, 5);";
                $result = $conn->query($sql);

                while($row = $result -> fetch_array()) {
                    $id = $row[0];
                    $gromady = $row[1];
                    $gatunek = $row[2];
                    $wystepowanie = $row[3];

                    if($gromady == 4) {
                        $gromady = "ptaki";
                    }
                    else if($gromady == 5) {
                        $gromady = "ssaki";
                    }

                    echo "<p>$id. $gatunek</p>";
                    echo "<p>Występowanie: $wystepowanie, gromada $gromady</p>";
                    echo "<hr>";
                }
            ?>
        </div>

        <div id="prawy">
            <h1>PTAKI</h1>
            <ol>
                <?php
                    // Skrypt #2
                    $sql = "SELECT gatunek, obraz FROM zwierzeta WHERE Gromady_id = 4;";
                    $result = $conn->query($sql);
                    
                    while($row = $result -> fetch_array()) {
                        echo "<li><a href='".$row["obraz"]."'>".$row["gatunek"]."</a></li>";
                    }
                ?>
            </ol>
            <img src="sroka.jpg" alt="Sroka zwyczajna, gromada ptaki">
        </div>

        <footer>
            Stronę o kręgowcach przygotował: <a href="https://ee-informatyk.pl/" target="_blank" style="color: #fff;text-decoration: none;">EE-Informatyk.pl</a>
        </footer>
    </body>
</html>

<?php
    $conn -> close();
?>