<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Ogłoszenia drobne</title>
        <link rel="stylesheet" href="styl2.css">
    </head>
    <body>
        <header>
            <h2>Ogłoszenia drobne</h2>
        </header>

        <div id="lewy">
            <h2>Ogłoszeniodawcy</h2>
            <?php
                // Skrypt #1
                $conn = new mysqli("localhost","root","","ogloszenia");

                $sql1 = "SELECT id, imie, nazwisko, email FROM uzytkownik WHERE id < 4;";
                $sql2 = "SELECT tytul FROM ogloszenie";
                $result1 = $conn->query($sql1);
                $result2 = $conn->query($sql2);

                while($row1 = $result1 -> fetch_array()) {
                    echo "<h3>".$row1["id"]." ".$row1["imie"]." ".$row1["nazwisko"]."</h3><p>".$row1["email"]."</p>";
                    $row2 = $result2 -> fetch_array();
                    echo "Ogłoszenie: ".$row2["tytul"]."<br>";
                }

                $conn -> close();
            ?>
        </div>

        <div id="prawy">
            <h2>Nasze kategorie</h2>
            <ul>
                <li>Książki</li>
                <li>Muzyka</li>
                <li>Multimedia</li>
            </ul>
            <img src="ksiazki.jpg" alt="uwolnij swoją książkę">

            <table>
                <tr>
                    <td>Ile?</td>
                    <td>Koszt</td>
                    <td>Promocja</td>
                </tr>

                <tr>
                    <td>1 - 40</td>
                    <td>1,20 PLN</td>
                    <td rowspan=2>Subskrybuj newsletter upust 0,30 PLN na ogłoszenie</td>
                </tr>

                <tr>
                    <td>41 i więcej</td>
                    <td>0,70 PLN</td>
                </tr>
            </table>
        </div>

        <footer>
            <p>Portal ogłoszenia drobne opracował: <a href="https://ee-informatyk.pl/" target="_blank" style="color: #fff;">EE-Informatyk.pl</a></p>
        </footer>
    </body>
</html>