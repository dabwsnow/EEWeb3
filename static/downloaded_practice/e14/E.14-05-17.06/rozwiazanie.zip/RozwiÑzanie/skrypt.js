function kalkulator() {
    let metry1 = document.getElementById("metry1").value;
    let metry2 = document.getElementById("metry2").value;

    let powierzchnia = ((metry1 * 2.7) * 2) + ((metry2 * 2.7) * 2);
    let koszt = powierzchnia * 8;
    document.getElementById("wynik1").innerHTML = "Powierzchnia całkowita ścian: " + powierzchnia;
    document.getElementById("wynik2").innerHTML = "Koszt malowania: " + koszt + " zł";
}