<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Nasze hobby</title>
        <link rel="stylesheet" href="hobby.css">
    </head>
    <body>
        <header>
            <h1>FORUM HOBBYSTYCZNE</h1>
        </header>

        <div id="lewy">
            <?php
                // Skrypt #1
                if(isset($_POST["nick"])) {
                    $nick = $_POST["nick"];
                    $hobby = $_POST["hobby"];
                    $zawod = $_POST["zawod"];
                    $plec = $_POST["plec"];
                    $login = $_POST["login"];
                    $haslo = $_POST["haslo"];

                    $conn = new mysqli("localhost","root","","forum");

                    $sql = "INSERT INTO `uzytkownicy` (`id`, `nick`, `zainteresowania`, `zawod`, `plec`) VALUES (NULL, '$nick', '$hobby', '$zawod', '$plec');";
                    $result = $conn->query($sql);

                    $sql2 = "INSERT INTO `konta` (`id`, `login`, `haslo`) VALUES (NULL, '$login', '$haslo');";
                    $result2 = $conn->query($sql2);

                    $conn -> close();

                    echo "Konto $nick zostało zarejestrowane na forum hobbystycznym";
                }
            ?>
        </div>

        <div id="prawy">
            <h3>TEMATY NA FORUM</h3>
            <ul>
                <li>Hodowla zwierząt</li>
                <ul>
                    <li>psy</li>
                    <li>koty</li>
                </ul>
                <li>Muzyka</li>
                <li>Gry komputerowe</li>
            </ul>
        </div>
    </body>
</html>