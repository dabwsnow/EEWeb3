<?php
    $conn = new mysqli("localhost","root","","sklep");
?>

<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Artykuły biurowe</title>
        <link rel="stylesheet" href="styl.css">
    </head>
    <body>
        <header>
            <h1>W naszej hurtowni kupisz najtaniej</h1>
        </header>

        <div id="lewy">
            <h4>Ile będą kosztować Twoje zakupy?</h4>
            <form action="index.php" method="post">
                <label for="artykul">wybierz artykuł</label>
                <select name="artykul" id="artykul">
                    <option value="Zeszyt 60 kartek">Zeszyt 60 kartek</option>
                    <option value="Zeszyt 32 kartki">Zeszyt 32 kartki</option>
                    <option value="Cyrkiel">Cyrkiel</option>
                    <option value="Linijka 30 cm">Linijka 30 cm</option>
                    <option value="Ekierka">Ekierka</option>
                    <option value="Linijka 50 cm">Linijka 50 cm</option>
                </select><br>
                <label for="sztuk">liczba sztuk: </label>
                <input type="number" name="sztuk" id="sztuk" value="0"><br>
                <button type="submit">OBLICZ</button>
            </form>
            <?php
                // Skrypt #2
                if(isset($_POST["artykul"]) && isset($_POST["sztuk"])) {
                    $artykul = $_POST["artykul"];
                    $sztuk = $_POST["sztuk"];

                    $sql = "SELECT cena FROM towary WHERE nazwa='$artykul';";
                    $result = $conn->query($sql);

                    while($row = $result -> fetch_array()) {
                        $cena = $row["cena"];
                        $cena = $cena * $sztuk;
                        $cena = round($cena, 1);
                        echo "Za $artykul w ilości $sztuk zapłacisz $cena";
                    }
                }
            ?>
        </div>

        <div id="srodkowy">
            <img src="zakupy2.png" alt="hurtownia">
            <h4>Kontakt</h4>
            <p>telefon: 888999777<br>e-mail: <a href="mailto:hurt@wp.pl">hurt@wp.pl</a></p>
        </div>

        <div id="prawy">
            <h4>Ceny wybranych artykułów w hurtowni:</h4>
            <table>
                <?php
                    // Skrypt #1
                    $sql = "SELECT nazwa, cena FROM towary LIMIT 4;";
                    $result = $conn->query($sql);
                    
                    while($row = $result -> fetch_array()) {
                        echo "<tr>";
                            echo "<td>".$row["nazwa"]."</td>";
                            echo "<td>".$row["cena"]."</td>";
                        echo "</tr>";
                    }
                ?>
            </table>
        </div>

        <footer>
            <h2>Witrynę wykonał <a href="https://ee-informatyk.pl/" target="_blank" style="color: unset;text-decoration: none;">EE-Informatyk.pl</a></h2>
        </footer>
    </body>
</html>

<?php
    $conn -> close();
?>