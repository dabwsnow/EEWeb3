function oblicz() {
    let osoby = document.getElementById("osoby").value;
    let poprawiny = document.getElementById("poprawiny").checked;
    let koszt = osoby * 100;
    if (poprawiny) {
        koszt += koszt * 0.3
    }
    document.getElementById("wynik").innerHTML = "Koszt Twojego wesela to " + koszt + " złotych";
}