<?php
    $conn = new mysqli("localhost","root","","baza");
?>

<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Dane o zwierzętach</title>
        <link rel="stylesheet" href="styl3.css">
    </head>
    <body>
        <header>
            <h1>ATLAS ZWIERZĄT</h1>
        </header>

        <div id="formularz">
            <h2>Gromady:</h2>
            <ol>
                <li>Ryby</li>
                <li>Płazy</li>
                <li>Gady</li>
                <li>Ptaki</li>
                <li>Ssaki</li>
            </ol>
            <form action="index.php" method="post">
                <label for="gromada">Wybierz gromadę: </label>
                <input type="number" name="gromada" id="gromada">
                <button type="submit">Wyświetl</button>
            </form>
        </div>

        <div id="lewy">
            <img src="zwierzeta.jpg" alt="dzikie zwierzęta">
        </div>

        <div id="srodkowy">
            <?php
                // Skrypt #1
                if(isset($_POST["gromada"])) {
                    $gromada = $_POST["gromada"];

                    if($gromada == 1) {
                        $tytul = "<h2>RYBY</h2>";
                    }
                    else if($gromada == 2) {
                        $tytul = "<h2>PŁAZY</h2>";
                    }
                    else if($gromada == 3) {
                        $tytul = "<h2>GADY</h2>";
                    }
                    else if($gromada == 4) {
                        $tytul = "<h2>PTAKI</h2>";
                    }
                    else if($gromada == 5) {
                        $tytul = "<h2>SSAKI</h2>";
                    }

                    $sql = "SELECT gatunek, wystepowanie FROM zwierzeta WHERE Gromady_id = $gromada;";
                    $result = $conn->query($sql);

                    echo $tytul;

                    while($row = $result -> fetch_array()) {
                        echo $row["gatunek"]." ".$row["wystepowanie"]."<br>";
                    }
                }
            ?>
        </div>

        <div id="prawy">
            <h2>Wszystkie zwierzęta w bazie</h2>
            <?php
                // Skrypt #2
                $sql = "SELECT zwierzeta.id, zwierzeta.gatunek, gromady.nazwa FROM zwierzeta INNER JOIN gromady ON zwierzeta.Gromady_id = gromady.id;";
                $result = $conn->query($sql);

                while($row = $result -> fetch_array()) {
                    echo $row[0].". ".$row[1].", ".$row[2]."<br>";
                }
            ?>
        </div>

        <footer>
            <a href="atlas-zwierzat.pl" target="_blank">Poznaj inne strony o zwierzętach</a>, autor Atlasu zwierząt: <a href="https://ee-informatyk.pl/" target="_blank" style="color: unset;text-decoration: none;">EE-Informatyk.pl</a>
        </footer>
    </body>
</html>

<?php
    $conn -> close();
?>