function czas() {
    document.write(document.lastModified)
}   