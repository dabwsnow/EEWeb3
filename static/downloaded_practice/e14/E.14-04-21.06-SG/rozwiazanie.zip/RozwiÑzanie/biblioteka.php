<?php
    $conn = new mysqli("localhost","root","","biblioteka");
?>

<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Biblioteka</title>
        <link rel="stylesheet" href="styl.css">
    </head>
    <body>
        <header>
            <h3>Miejska Biblioteka Publiczna w Książkowicach</h3>
        </header>

        <div id="lewy">
            <h4>Nasi czytelnicy: </h4>
            <ul>
                <?php
                    // Skrypt #1
                    $sql = "SELECT imie, nazwisko FROM czytelnicy;";
                    $result = $conn->query($sql);

                    while($row = $result -> fetch_array()) {
                        echo "<li>".$row[0]." ".$row[1]."</li>";
                    }
                ?>
            </ul>
        </div>

        <div id="srodkowy">
            <h5>ul. Czytelnicza 25<br>12-120 Książkowice<br>tel.: 777888666<br>e-mail: <a href="mailto:biuro@bib.pl">biuro@bib.pl</a></h5>
            <img src="biblioteka.png" alt="biblioteka">
        </div>

        <div id="prawy">
            <h4>Dodaj czytelnika</h4>
            <form action="biblioteka.php" method="post">
                <label for="imie">imię: </label><input type="text" name="imie" id="imie"><br>
                <label for="nazwisko">nazwisko: </label><input type="text" name="nazwisko" id="nazwisko"><br>
                <label for="rok">rok urodzenia: </label><input type="number" name="rok" id="rok"><br>
                <button type="submit">DODAJ</button>
            </form>
            <?php
                // Skrypt #2
                if(isset($_POST["imie"]) && isset($_POST["nazwisko"]) && isset($_POST["rok"])) {
                    $imie = $_POST["imie"];
                    $nazwisko = $_POST["nazwisko"];
                    $rok = $_POST["rok"];
                    $kod = strtolower(substr($imie, 0, 2) . substr($rok, -2) . substr($nazwisko, 0, 2));

                    $sql = "INSERT INTO czytelnicy (imie, nazwisko, kod) VALUES ('$imie', '$nazwisko', '$kod');";
                    $result = $conn->query($sql);

                    echo "Czytelnik: $nazwisko został dodany do bazy danych";
                }
            ?>
        </div>

        <footer>
            <p>Projekt witryny: <a href="https://ee-informatyk.pl/" target="_blank" style="color: unset;text-decoration: none;">EE-Informatyk.pl</a></p>
        </footer>
    </body>
</html>

<?php
    $conn -> close();
?>