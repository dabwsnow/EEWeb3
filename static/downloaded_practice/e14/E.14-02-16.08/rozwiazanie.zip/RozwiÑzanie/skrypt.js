function weryfikuj(){
    let haslo = document.getElementById('haslo').value;
    let wynik = document.getElementById('wynik');
    if (haslo == '') {
        wynik.innerHTML = 'Hasło jest puste';
        wynik.style.color = 'red';
    }
    else if (haslo.length >= 4 && haslo.length <= 6 && haslo.match(/\d+/)) {
        wynik.innerHTML = 'Hasło jest średnie';
        wynik.style.color = 'blue';
    }
    else if (haslo.length >= 7 && haslo.match(/\d+/)) {
        wynik.innerHTML = 'Hasło jest dobre';
        wynik.style.color = 'green';
    }
    else {
        wynik.innerHTML = 'Hasło jest słabe';
        wynik.style.color = 'yellow';
    }
}