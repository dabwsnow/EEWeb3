function sprawdz() {
    let haslo = document.getElementById("haslo").value;
    let wynik = document.getElementById("wynik");
    let cyfra = false;
    if (haslo.length > 0) {
        for (let i = 0; i < haslo.length; i++) {
            if (!isNaN(haslo[i])) {
                cyfra = true;
            }
        }
        if (haslo.length >= 7 && cyfra == true) {
            wynik.style.color = "red";
            wynik.innerHTML = "DOBRE";
        }
        else if (haslo.length >= 4 && haslo.length <= 6 && cyfra == true) {
            wynik.style.color = "blue";
            wynik.innerHTML = "ŚREDNIE";
        }
        else {
            wynik.style.color = "yellow";
            wynik.innerHTML = "SŁABE";
        }
    }
    else {
        wynik.style.color = "red";
        wynik.innerHTML = "WPISZ HASŁO!";
    }
}