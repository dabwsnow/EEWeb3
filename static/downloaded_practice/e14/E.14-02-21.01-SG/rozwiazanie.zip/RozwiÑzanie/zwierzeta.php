<?php
    $conn = new mysqli("localhost","root","","baza");
?>

<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Zwierzęta</title>
        <link rel="stylesheet" href="styl2.css">
    </head>
    <body>
        <div id="logo">
            <h1>KRĘGOWCE</h1>
        </div>

        <div id="menu">
            <a href="ryby.html">RYBY</a>
            <a href="ptaki.html">PTAKI</a>
            <a href="ssaki.html">SSAKI</a>
        </div>

        <div id="lewy">
            <h2>SSAKI</h2>
            <ul>
                <?php
                    // Skrypt #1
                    $sql = "SELECT gatunek, obraz FROM zwierzeta WHERE Gromady_id = 5;";
                    $result = $conn->query($sql);

                    while($row = $result -> fetch_array()) {
                        echo "<a href='".$row["obraz"]."'><li>".$row["gatunek"]."</a></li>";
                    }
                ?>
            </ul>
            <img src="wilk.jpg" alt="Wilk szary, gromada ssaki">
        </div>

        <div id="prawy">
            <?php
                // Skrypt #2
                $sql = "SELECT gatunek, wystepowanie, czy_zagrozony FROM zwierzeta WHERE Gromady_id IN (1, 4, 5);";
                $result = $conn->query($sql);

                while($row = $result -> fetch_array()) {
                    if($row["czy_zagrozony"] == 1) {
                        $zagrozony = "gatunek jest zagrożony";
                    }
                    else {
                        $zagrozony = "gatunek nie jest zagrożony";
                    }

                    echo "<p>".$row["gatunek"]."</p>";
                    echo "<p>Występowanie: ".$row["wystepowanie"].", $zagrozony</p>";
                    echo "<hr>";
                }
            ?>
        </div>

        <footer>
            Stronę o zwierzętach przygotował: <a href="https://ee-informatyk.pl/" target="_blank" style="color: unset;text-decoration: none;">EE-Informatyk.pl</a>
        </footer>
    </body>
</html>

<?php
    $conn -> close();
?>