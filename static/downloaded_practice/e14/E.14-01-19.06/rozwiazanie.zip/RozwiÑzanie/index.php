<?php
    $conn = new mysqli("localhost","root","","sklep");
?>

<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sklep papierniczy</title>
        <link rel="stylesheet" href="styl.css">
    </head>
    <body>
        <header>
            <h1>W naszym sklepie internetowym kupisz najtaniej</h1>
        </header>

        <div id="lewy">
            <h3>Promocja 15% obejmuje artykuły: </h3>
            <?php
                // Skrypt #1
                echo "<ul>";
                $sql = "SELECT nazwa FROM towary WHERE promocja = 1;";
                $result = $conn->query($sql);

                while($row = $result -> fetch_array()) {
                    echo "<li>".$row["nazwa"]."</li>";
                }
                echo "</ul>";
            ?>
        </div>

        <div id="srodek">
            <h3>Cena wybranego artykułu w promocji</h3>
            <form action="index.php" method="post">
                <select name="lista" id="lista">
                    <option value="Gumka do mazania">Gumka do mazania</option>
                    <option value="Cienkopis">Cienkopis</option>
                    <option value="Pisaki 60 szt.">Pisaki 60 szt.</option>
                    <option value="Markery 4 szt.">Markery 4 szt.</option>
                </select>
                <button type="submit">WYBIERZ</button>
            </form>
            <?php
                // Skrypt #2
                if(isset($_POST["lista"])) {
                    $lista = $_POST["lista"];
                    $sql = "SELECT cena FROM towary WHERE nazwa = '$lista';";
                    $result = $conn->query($sql);

                    while($row = $result -> fetch_array()) {
                        $cena = $row[0] * 0.85;
                        $cena = round($cena, 2);
                        echo "Atykuł $lista w promocji kosztuje $cena";
                    }
                }
            ?>
        </div>

        <div id="prawy">
            <h3>Kontakt</h3>
            <p>telefon: 123123123<br>e-mail: <a href="mailto:bok@sklep.pl">bok@sklep.pl</a></p>
            <img src="promocja2.png" alt="promocja">
        </div>

        <footer>
            <h4>Autor strony <a href="https://ee-informatyk.pl/" target="_blank" style="color: #000;text-decoration: none;">EE-Informatyk.pl</a></h4>
        </footer>
    </body>
</html>

<?php
    $conn -> close();
?>