<?php

    if(isset($_POST["imie"])) {
        $imie = $_POST["imie"];
        $nazwisko = $_POST["nazwisko"];
        $telefon = $_POST["telefon"];
        $email = $_POST["email"];

        $conn = new mysqli("localhost","root","","ogloszenia");

        $sql = "INSERT INTO uzytkownik (id, imie, nazwisko, telefon, email) VALUES (NULL, '$imie', '$nazwisko', '$telefon', '$email');";
        $result = $conn->query($sql);

        $conn -> close();

        echo "Pomyślnie dodano użytkownika";
    }
?>