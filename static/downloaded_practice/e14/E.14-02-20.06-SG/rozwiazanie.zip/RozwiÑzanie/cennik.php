<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Pokoje</title>
        <link rel="stylesheet" href="styl.css">
    </head>
    <body>
        <div id="baner1">
            <h2>WYNAJEM POKOI</h2>
        </div>

        <div id="menu1">
            <a href="index.html">POKOJE</a>
        </div>

        <div id="menu2">
            <a href="cennik.php">CENNIK</a>
        </div>

        <div id="menu3">
            <a href="kalkulator.html">KALKULATOR</a>
        </div>

        <div id="baner2">

        </div>
        
        <div id="lewy">

        </div>

        <div id="srodkowy">
            <h1>Cennik</h1>
            <table>
                <?php
                    // Skrypt #1
                    $conn = new mysqli("localhost","root","","wynajem");

                    $sql = "SELECT * FROM pokoje;";
                    $result = $conn->query($sql);

                    while($row = $result -> fetch_array()) {
                        echo "<tr>";
                            echo "<td>".$row[0]."</td>";
                            echo "<td>".$row[1]."</td>";
                            echo "<td>".$row[2]."</td>";
                        echo "</tr>";
                    }

                    $conn -> close();
                ?>
            </table>
        </div>

        <div id="prawy">

        </div>

        <footer>
            <p>Stronę opracował: <a href="https://ee-informatyk.pl/" target="_blank" style="color: unset;text-decoration: none;">EE-Informatyk.pl</a></p>
        </footer>
    </body>
</html>