function oblicz() {
    var miejscowosc = document.getElementById("miejscowosc");
    var odleglosc = document.getElementById("odleglosc");
    var wynik = document.getElementById("wynik");

    if(miejscowosc.checked == true) {
        wynik.innerHTML = "Dowieziemy Twoją pizzę za darmo";
    }
    else {
        wynik.innerHTML = "Dowóz będzie Cię kosztował " + odleglosc.value*2 + " złotych";
    }
}