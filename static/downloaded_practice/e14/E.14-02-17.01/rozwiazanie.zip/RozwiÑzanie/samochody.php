<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Wynajmujemy samochody</title>
        <link rel="stylesheet" href="styl.css">
    </head>
    <body>
        <header>
            <h1>Wynajem Samochodów</h1>
        </header>

        <div id="lewy">
            <h2>DZIŚ POLECAMY TOYOTĘ ROCZNIK 2014</h2>

            <?php
                // Skrypt #1
                $conn = new mysqli("localhost","root","","wynajem");

                $sql = "SELECT id,model,kolor FROM Samochody WHERE marka='Toyota' AND rocznik=2014;";
                $result = $conn->query($sql);

                while($row = $result -> fetch_array()) {
                    echo $row["id"]." Toyota ".$row["model"].". Kolor: ".$row["kolor"];
                }

                $conn -> close();
            ?>

            <h2>WSZYSTKIE DOSTĘPNE SAMOCHODY</h2>

            <?php
                // Skrypt #2
                $conn = new mysqli("localhost","root","","wynajem");

                $sql = "SELECT id,marka,model,rocznik FROM Samochody;";
                $result = $conn->query($sql);

                while($row = $result -> fetch_array()) {
                    echo $row["id"]." ".$row["marka"]." ".$row["model"]." ".$row["rocznik"]."<br>";
                }

                $conn -> close();
            ?>
        </div>

        <div id="srodkowy">
            <h2>ZAMWIONE AUTA Z NUMERAMI TELEFONÓW KLIENTÓW</h2>

            <?php
                // Skrypt #3
                $conn = new mysqli("localhost","root","","wynajem");

                $sql = "SELECT samochody.id, model, telefon FROM samochody JOIN zamowienia ON samochody.id = zamowienia.Samochody_id;";
                $result = $conn->query($sql);

                while($row = $result -> fetch_array()) {
                    echo $row[0]." ".$row["model"]." ".$row["telefon"]."<br>";
                }

                $conn -> close();
            ?>
        </div>

        <div id="prawy">
            <h2>NASZA OFERTA</h2>

            <ul>
                <li>Fiat</li>
                <li>Toyota</li>
                <li>Opel</li>
                <li>Mercedes</li>
            </ul>

            <p>Tu pobierzesz naszą <a href="samochody.sql">bazę danych</a></p>
            <p>autor strony: <a href="https://ee-informatyk.pl/" target="_blank">EE-Informatyk.pl</a></p>
        </div>
    </body>
</html>