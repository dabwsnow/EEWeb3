function najechanie(imgId, szaryImg) {
    document.getElementById(imgId).src = szaryImg;
}

function opuszczenie(imgId, kolorImg) {
    document.getElementById(imgId).src = kolorImg;
}

function klikniecie(imgId, kolorImg) {
    document.getElementById(imgId).src = kolorImg;
    document.getElementById("prawy2").innerHTML = `<p><img src="${kolorImg}" alt="Wybrany pies"></p>`;
}