function oblicz() {
    let sredniapolak = document.getElementById("sredniapolak").value;
    let srednianowak = document.getElementById("srednianowak").value;
    let sredniarysik = document.getElementById("sredniarysik").value;

    if (sredniapolak == "" || srednianowak == "" || sredniarysik == "" || isNaN(sredniapolak) || isNaN(srednianowak) || isNaN(sredniarysik)) {
        alert("wpisz poprawne dane");
    }
    else {
        sredniapolak = Number(sredniapolak);
        srednianowak = Number(srednianowak);
        sredniarysik = Number(sredniarysik);
        let wynik = (sredniapolak + srednianowak + sredniarysik) / 3;
        document.getElementById("wynik").innerHTML = `Średnia ocen: ${wynik}`;
    }
}