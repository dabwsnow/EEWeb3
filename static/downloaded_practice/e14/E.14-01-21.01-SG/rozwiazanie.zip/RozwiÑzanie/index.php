<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Podzespoły komputerowe</title>
        <link rel="stylesheet" href="styl_1.css">
    </head>
    <body>
        <div id="logo">
            <h1>Sklep Komputerowy</h1>
        </div>

        <div id="menu">
            <a href="index.php">Główna</a>
            <a href="procesory.html">Procesory</a>
            <a href="ram.html">Ram</a>
            <a href="grafika.html">Grafika</a>
            <a href="hdd.html">HDD</a>
        </div>

        <main>
            <h2>Lista aktualnie dostępnych podzespołów</h2>
            <table>
                <tr>
                    <th>NAZWA PODZESPOŁU</th>
                    <th>OPIS</th>
                    <th>CENA</th>
                </tr>

                <?php
                    // Skrypt #1
                    $conn = new mysqli("localhost","root","","sklep");

                    $sql = "SELECT nazwa, opis, cena FROM podzespoly WHERE dostepnosc = 1;";
                    $result = $conn->query($sql);

                    while($row = $result -> fetch_array()) {
                        echo "<tr>";
                            echo "<td>".$row["nazwa"]."</td>";
                            echo "<td>".$row["opis"]."</td>";
                            echo "<td>".$row["cena"]."</td>";
                        echo "</tr>";
                    }

                    $conn -> close();
                ?>
            </table>
        </main>

        <div id="stopka1">
            <h3>Sklep Komputerowy</h3>
            <p>ul. Legnicka 61, Wrocław</p>
            <p>Współpracujemy z hurtownią <a href="http://www.ddata.pl/" target="_blank">ddata</a></p>
        </div>

        <div id="stopka2">
            <p>Stronę wykonał: <a href="https://ee-informatyk.pl/" target="_blank" style="color: unset;text-decoration: none;">EE-Informatyk.pl</a></p>
        </div>

        <div id="stopka3">
            <p>zadzwoń do nas: 71 506 50 60</p>
        </div>

        <div id="stopka4">
            <img src="sklep.jpg" alt="sklep komputerowy">
        </div>
    </body>
</html>