<?php
    $conn = new mysqli("localhost","root","","szkola");
?> 

<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Szkoła Podstawowa</title>
        <link rel="stylesheet" href="styl.css">
    </head>
    <body>
        <header>
            <h1>Oceny uczniów: biologia</h1>
        </header>

        <div id="lewy">
            <?php
                // Skrypt #1
                $sql = "SELECT imie,nazwisko FROM uczen WHERE id=1;";
                $result = $conn->query($sql);

                while($row = $result -> fetch_array()) {
                    echo "<h3>Uczeń: ".$row["imie"]." ".$row["nazwisko"]."</h3>";
                }

                $sql = "SELECT MAX(ocena) FROM ocena WHERE przedmiot_id = 4 AND uczen_id = 1;";
                $result = $conn->query($sql);

                while($row = $result -> fetch_array()) {
                    echo "<p>Najwyższa ocena z biologii: ".$row[0]."</p>";
                }
            ?>
        </div>

        <div id="prawy">
            <h3>Nazwiska i numery PESEL uczniów: </h3>
            <ul>
                <?php
                    // Skrypt #2
                    $sql = "SELECT nazwisko,pesel FROM uczen;";
                    $result = $conn->query($sql);

                    while($row = $result -> fetch_array()) {
                        echo "<li>".$row["nazwisko"]." ".$row["pesel"]."</li>";
                    }
                ?>
            </ul>
        </div>

        <footer>
            <h2>Szkoła Podstawowa</h2>
            <p>Stronę opracował: <a href="https://ee-informatyk.pl/" target="_blank" style="color: unset;text-decoration: none;">EE-Informatyk.pl</a></p>
        </footer>
    </body>
</html>

<?php
    $conn -> close();
?>