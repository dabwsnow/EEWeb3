function przelicz() {
    let powierzchnia = document.getElementById("powierzchnia").value;
    let rodzaj = document.querySelector('input[name="rodzaj"]:checked').value;
    let wybor = powierzchnia * rodzaj;
    document.getElementById('wynik').innerHTML = "Koszt kafelkowania: " + wybor + " zł";
}