<?php
    $conn = new mysqli("localhost","root","","sklep");
?>

<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Hurtownia papiernicza</title>
        <link rel="stylesheet" href="styl.css">
    </head>
    <body>
        <header>
            <h1>W naszej hurtowni kupisz najtaniej</h1>
        </header>

        <div id="lewy">
            <h3>Ceny wybranych artykułów w hurtowni:</h3>

            <table>
            <?php
                // Skrypt #1
                echo "<tr></tr>";


                $sql = "SELECT nazwa, cena FROM towary LIMIT 4;";
                $result = $conn->query($sql);

                while($row = $result -> fetch_array()) {
                    echo "<tr>";
                        echo "<td>".$row["nazwa"]."</td>";
                        echo "<td>".$row["cena"]."</td>";
                    echo "</tr>";
                }
            ?>
            </table>
        </div>

        <div id="srodek">
            <h3>Ile będą kosztować Twoje zakupy?</h3>
            <form action="index.php" method="post">
                wybierz artykuł
                <select name="artykul" id="artykul">
                    <option value="Zeszyt 60 kartek">Zeszyt 60 kartek</option>
                    <option value="Zeszyt 32 kartki">Zeszyt 32 kartki</option>
                    <option value="Cyrkiel">Cyrkiel</option>
                    <option value="Linijka 30 cm">Linijka 30 cm</option>
                    <option value="Ekierka">Ekierka</option>
                    <option value="Linijka 50 cm">Linijka 50 cm</option>
                </select><br>
                liczba sztuk: <input type="number" name="liczba" id="liczba" value="1"><br>
                <button type="submit">OBLICZ</button>
            </form>
            <?php
                // Skrypt #2
                if(isset($_POST["artykul"]) && isset($_POST["liczba"])) {
                    $artykul = $_POST["artykul"];
                    $liczba = $_POST["liczba"];

                    $sql = "SELECT cena FROM towary WHERE nazwa = '$artykul';";
                    $result = $conn->query($sql);

                    while($row = $result -> fetch_array()) {
                        $cena = $row[0];
                        $cena = $cena * $liczba;
                        $cena = round($cena, 1);
                        
                        echo "Przedmiot: $artykul, ilość: $liczba, cena: $cena";
                    }
                }
            ?>  
        </div>

        <div id="prawy">
            <img src="zakupy2.png" alt="hurtownia">
            <h3>Kontakt</h3>
            <p>telefon:<br>111222333<br>e-mail:<br><a href="mailto:hurt@wp.pl">hurt@wp.pl</a></p>
        </div>

        <footer>
            <h4>Witrynę wykonał <a href="https://ee-informatyk.pl/" target="_blank" style="color: #000;text-decoration: none;">EE-Informatyk.pl</a></h4>
        </footer>
    </body>
</html>

<?php
    $conn -> close();
?>