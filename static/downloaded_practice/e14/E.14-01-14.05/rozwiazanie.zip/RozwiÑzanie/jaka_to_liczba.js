let haslo = prompt("Podaj hasło");
                
if (haslo == "liczba") {
    let liczba = prompt("Podaj liczbę całkowitą");
    if (liczba > 0) {
        alert("Liczba " + liczba + " jest dodatnia");
    }
    else if (liczba < 0) {
        alert("Liczba " + liczba + " jest ujemna");
    }
    else {
        alert("Liczba " + liczba + " to zero");
    }
}
else {
    alert("Błędne hasło!");
}