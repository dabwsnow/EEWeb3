var poczatkowa = prompt("Podaj liczbę początkową");
var koncowa = prompt("Podaj liczbę końcową");
var wynik = "";

if (poczatkowa > koncowa) {
    while (poczatkowa >= koncowa) {
        wynik += poczatkowa + " ";
        poczatkowa--;
    }
}
else if (poczatkowa < koncowa) {
    while (poczatkowa <= koncowa) {
        wynik += poczatkowa + " ";
        poczatkowa++;
    }
}
else {
    wynik = poczatkowa;
}
alert(wynik);