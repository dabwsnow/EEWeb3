<?php
    $conn = new mysqli("localhost","root","","dane");
?>

<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Filmoteka</title>
        <link rel="stylesheet" href="styl3.css">
    </head>
    <body>
        <div id="naglowek1">
            <img src="klaps.png" alt="Nasze filmy">
        </div>

        <div id="naglowek2">
            <h1>BAZA FILMÓW</h1>
        </div>

        <div id="naglowek3">
            <form action="index.php" method="post">
                <select name="lista" id="lista">
                    <option value="Sci-Fi">Sci-Fi</option>
                    <option value="animacja">animacja</option>
                    <option value="dramat">dramat</option>
                    <option value="horror">horror</option>
                    <option value="komedia">komedia</option>
                </select>
                <button type="submit">Filmy</button>
            </form>
        </div>

        <div id="naglowek4">
            <img src="gwiezdneWojny.jpg" alt="szturmowcy">
        </div>

        <div id="lewy">
            <h2>Wybrano filmy:</h2>
            <?php
                // Skrypt #1

                if(isset($_POST["lista"])) {
                    $lista = $_POST["lista"];

                    $sql = "SELECT tytul, rok, ocena FROM filmy, gatunki WHERE filmy.gatunki_id = gatunki.id AND gatunki.nazwa = '$lista';";
                    $result = $conn->query($sql);

                    while($row = $result -> fetch_array()) {
                        echo "<p>Tytuł: ".$row["tytul"].", Rok produkcji: ".$row["rok"].", Ocena: ".$row["ocena"]."</p>";
                    }
                }
            ?>
        </div>

        <div id="prawy">
            <h2>Wszystkie filmy</h2>
            <?php
                // Skrypt #2
                $sql = "SELECT filmy.id, filmy.tytul, rezyserzy.imie, rezyserzy.nazwisko FROM filmy, rezyserzy WHERE filmy.rezyserzy_id = rezyserzy.id;";
                $result = $conn->query($sql);

                while($row = $result -> fetch_array()) {
                    echo "<p>".$row[0].". ".$row[1].", reżyseria: ".$row[2]." ".$row[3]."</p>";
                }
            ?>
        </div>

        <footer>
            <p>Autor: <a href="https://ee-informatyk.pl/" target="_blank" style="color: orange;text-decoration: none;">EE-Informatyk.pl</a></p>
            <a href="kwerendy.txt">Zapytania do bazy</a> <a href="filmy.pl" target="_blank">Przejdź do filmy.pl</a>
        </footer>
    </body>
</html>

<?php
    $conn -> close();
?>