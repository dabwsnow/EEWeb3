import java.util.Scanner;

class Sorter {
    private int[] numbers;

    public Sorter() {
        numbers = new int[10];
    }

    /********************************************************
    * nazwa funkcji: readNumbers
    * parametry wejściowe: brak
    * wartość zwracana: brak (wczytuje dane do tablicy `numbers` z klawiatury)
    * autor: ee-informatyk.pl
    ********************************************************/
    public void readNumbers() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Podaj 10 liczb całkowitych do posortowania:");
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = scanner.nextInt();
        }
    }

    /********************************************************
    * nazwa funkcji: sortDescending
    * parametry wejściowe: brak
    * wartość zwracana: brak (sortuje tablicę `numbers` malejąco)
    * autor: ee-informatyk.pl
    ********************************************************/
    public void sortDescending() {
        for (int i = 0; i < numbers.length - 1; i++) {
            int maxIndex = findMaxIndex(i);
            if (maxIndex != i) {
                int temp = numbers[i];
                numbers[i] = numbers[maxIndex];
                numbers[maxIndex] = temp;
            }
        }
    }

    /********************************************************
    * nazwa funkcji: findMaxIndex
    * parametry wejściowe: start - indeks w tablicy, od którego rozpoczyna się wyszukiwanie
    * wartość zwracana: indeks największej wartości w tablicy w zakresie od start do końca
    * autor: ee-informatyk.pl
    ********************************************************/
    private int findMaxIndex(int start) {
        int maxIndex = start;
        for (int i = start + 1; i < numbers.length; i++) {
            if (numbers[i] > numbers[maxIndex]) {
                maxIndex = i;
            }
        }
        return maxIndex;
    }

    /********************************************************
    * nazwa funkcji: displayNumbers
    * parametry wejściowe: brak
    * wartość zwracana: brak (wyświetla zawartość tablicy `numbers` na ekranie)
    * autor: ee-informatyk.pl
    ********************************************************/
    public void displayNumbers() {
        System.out.println("Posortowana tablica (malejąco):");
        for (int num : numbers) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}

public class Main {
    public static void main(String[] args) {
        Sorter sorter = new Sorter();
        sorter.readNumbers();
        sorter.sortDescending();
        sorter.displayNumbers();
    }
}
