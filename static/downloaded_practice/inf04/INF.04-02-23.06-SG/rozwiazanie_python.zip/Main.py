import random

class BubbleSortApp:

    @staticmethod
    def bubble_sort(array):
        n = len(array)
        for i in range(n - 1):
            for j in range(n - i - 1):
                if array[j] > array[j + 1]:
                    array[j], array[j + 1] = array[j + 1], array[j]

    @staticmethod
    def generate_random_array(size, min_value, max_value):
        return [random.randint(min_value, max_value) for _ in range(size)]

    @staticmethod
    def print_array(array):
        print(", ".join(map(str, array)))

if __name__ == "__main__":
    numbers = BubbleSortApp.generate_random_array(100, 0, 1000)

    print("Tablica przed sortowaniem:")
    BubbleSortApp.print_array(numbers)

    BubbleSortApp.bubble_sort(numbers)

    print("\nTablica po sortowaniu:")
    BubbleSortApp.print_array(numbers)
