import random

# ******************************************************
# nazwa funkcji: fill_array
# argumenty: 
#   array - lista liczb całkowitych, która będzie wypełniona wartościami
#   size - liczba elementów, które mają zostać wypełnione w liście
# typ zwracany: None, brak wartości zwracanej
# informacje: Funkcja wypełnia przekazaną listę pseudolosowymi liczbami z zakresu od 1 do 100.
# autor: EE-Informatyk.pl
# *****************************************************
def fill_array(array, size):
    for _ in range(size):
        array.append(random.randint(1, 100))

# ******************************************************
# nazwa funkcji: search_with_sentinel
# argumenty: 
#   array - lista liczb całkowitych, w której będzie wyszukiwana wartość
#   value_to_find - liczba całkowita, która ma zostać odnaleziona w liście
# typ zwracany: int, indeks pierwszego wystąpienia szukanej wartości lub -1, gdy nie znaleziono
# informacje: Funkcja przeszukuje listę za pomocą algorytmu z wartownikiem.
#             Wartownik jest tymczasowo dodawany na końcu listy, a następnie usuwany.
# autor: EE-Informatyk.pl
# *****************************************************
def search_with_sentinel(array, value_to_find):
    n = len(array)
    array.append(value_to_find)

    i = 0
    while array[i] != value_to_find:
        i += 1

    array.pop()

    if i == n:
        return -1
    return i

# ******************************************************
# nazwa funkcji: main
# argumenty: brak
# typ zwracany: None, brak wartości zwracanej
# informacje: Funkcja główna programu, która testuje działanie algorytmu.
#             Wypełnia listę pseudolosowymi liczbami, pobiera od użytkownika wartość do wyszukania,
#             wywołuje funkcję wyszukującą i wyświetla wyniki działania.
# autor: EE-Informatyk.pl
# *****************************************************
def main():
    ARRAY_SIZE = 50
    array = []
    value_to_find = int(input("Podaj wartosc do wyszukania: "))

    fill_array(array, ARRAY_SIZE)

    index = search_with_sentinel(array, value_to_find)

    print("Zawartosc listy: ")
    print(", ".join(map(str, array)))

    if index == -1:
        print(f"Nie znaleziono wartosci {value_to_find} w liscie.")
    else:
        print(f"Wartosc {value_to_find} odnaleziono pod indeksem: {index}")

if __name__ == "__main__":
    main()
