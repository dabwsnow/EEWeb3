import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main {

    /******************************************************
     nazwa funkcji: fillArray
     argumenty: 
       array - lista liczb całkowitych, która będzie wypełniona wartościami
       size - liczba elementów, które mają zostać wypełnione w liście
     typ zwracany: void, brak wartości zwracanej
     informacje: Funkcja wypełnia przekazaną listę pseudolosowymi liczbami z zakresu od 1 do 100.
     autor: EE-Informatyk.pl
     *****************************************************/
    public static void fillArray(ArrayList<Integer> array, int size) {
        Random rand = new Random();
        for (int i = 0; i < size; i++) {
            array.add(rand.nextInt(100) + 1);
        }
    }

    /******************************************************
     nazwa funkcji: searchWithSentinel
     argumenty: 
       array - lista liczb całkowitych, w której będzie wyszukiwana wartość
       valueToFind - liczba całkowita, która ma zostać odnaleziona w liście
     typ zwracany: int, indeks pierwszego wystąpienia szukanej wartości lub -1, gdy nie znaleziono
     informacje: Funkcja przeszukuje listę za pomocą algorytmu z wartownikiem.
                 Wartownik jest tymczasowo dodawany na końcu listy, a następnie usuwany.
     autor: EE-Informatyk.pl
     *****************************************************/
    public static int searchWithSentinel(ArrayList<Integer> array, int valueToFind) {
        int n = array.size();
        array.add(valueToFind);

        int i = 0;
        while (array.get(i) != valueToFind) {
            i++;
        }

        array.remove(n);

        if (i == n) {
            return -1;
        }
        return i;
    }

    /******************************************************
     nazwa funkcji: main
     argumenty: brak
     typ zwracany: void, brak wartości zwracanej
     informacje: Funkcja główna programu, która testuje działanie algorytmu.
                 Wypełnia listę pseudolosowymi liczbami, pobiera od użytkownika wartość do wyszukania,
                 wywołuje funkcję wyszukującą i wyświetla wyniki działania.
     autor: EE-Informatyk.pl
     *****************************************************/
    public static void main(String[] args) {
        final int ARRAY_SIZE = 50;
        ArrayList<Integer> array = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        System.out.print("Podaj wartosc do wyszukania: ");
        int valueToFind = scanner.nextInt();

        fillArray(array, ARRAY_SIZE);

        int index = searchWithSentinel(array, valueToFind);

        System.out.println("Zawartosc listy: ");
        for (int i : array) {
            System.out.print(i + ", ");
        }
        System.out.println();

        if (index == -1) {
            System.out.println("Nie znaleziono wartosci " + valueToFind + " w liscie.");
        } else {
            System.out.println("Wartosc " + valueToFind + " odnaleziono pod indeksem: " + index);
        }
        
        scanner.close();
    }
}
