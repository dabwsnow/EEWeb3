﻿using System;
using System.Collections.Generic;

class Program
{
    /******************************************************
     nazwa funkcji: fillArray
     argumenty: 
       array - lista liczb całkowitych, która będzie wypełniona wartościami
       size - liczba elementów, które mają zostać wypełnione w liście
     typ zwracany: void, brak wartości zwracanej
     informacje: Funkcja wypełnia przekazaną listę pseudolosowymi liczbami z zakresu od 1 do 100.
     autor: EE-Informatyk.pl
     *****************************************************/
    static void fillArray(List<int> array, int size) {
        Random rand = new Random();
        for (int i = 0; i < size; i++) {
            array.Add(rand.Next(1, 101));
        }
    }

    /******************************************************
     nazwa funkcji: searchWithSentinel
     argumenty: 
       array - lista liczb całkowitych, w której będzie wyszukiwana wartość
       valueToFind - liczba całkowita, która ma zostać odnaleziona w liście
     typ zwracany: int, indeks pierwszego wystąpienia szukanej wartości lub -1, gdy nie znaleziono
     informacje: Funkcja przeszukuje listę za pomocą algorytmu z wartownikiem.
                 Wartownik jest tymczasowo dodawany na końcu listy, a następnie usuwany.
     autor: EE-Informatyk.pl
     *****************************************************/
    static int searchWithSentinel(List<int> array, int valueToFind)
    {
        int n = array.Count;
        array.Add(valueToFind);

        int i = 0;
        while (array[i] != valueToFind) {
            i++;
        }

        array.RemoveAt(n);

        if (i == n) {
            return -1;
        }
        return i;
    }

    /******************************************************
     nazwa funkcji: Main
     argumenty: brak
     typ zwracany: void, brak wartości zwracanej
     informacje: Funkcja główna programu, która testuje działanie algorytmu.
                 Wypełnia listę pseudolosowymi liczbami, pobiera od użytkownika wartość do wyszukania,
                 wywołuje funkcję wyszukującą i wyświetla wyniki działania.
     autor: EE-Informatyk.pl
     *****************************************************/
    static void Main()
    {
        const int ARRAY_SIZE = 50;
        List<int> array = new List<int>();
        int valueToFind;
        fillArray(array, ARRAY_SIZE);
        Console.Write("Podaj wartosc do wyszukania: ");
        valueToFind = int.Parse(Console.ReadLine());
        int index = searchWithSentinel(array, valueToFind);
        Console.WriteLine("Zawartosc listy: ");
        Console.WriteLine(string.Join(", ", array));

        if (index == -1) {
            Console.WriteLine($"Nie znaleziono wartosci {valueToFind} w liscie.");
        }
        else {
            Console.WriteLine($"Wartosc {valueToFind} odnaleziono pod indeksem: {index}");
        }
    }
}
