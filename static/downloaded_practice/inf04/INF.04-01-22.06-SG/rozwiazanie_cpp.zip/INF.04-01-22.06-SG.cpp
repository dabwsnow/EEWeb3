#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>

using namespace std;

/******************************************************
 nazwa funkcji: fillArray
 argumenty:
   array - wektor liczb ca�kowitych, kt�ry b�dzie wype�niony warto�ciami
   size - liczba element�w, kt�re maj� zosta� wype�nione w wektorze
 typ zwracany: void, brak warto�ci zwracanej
 informacje: Funkcja wype�nia przekazany wektor pseudolosowymi liczbami z zakresu od 1 do 100.
 autor: EE-Informatyk.pl
 *****************************************************/
void fillArray(vector<int>& array, int size) {
    srand(time(0));
    for (int i = 0; i < size; ++i) {
        array.push_back(rand() % 100 + 1);
    }
}

/******************************************************
 nazwa funkcji: searchWithSentinel
 argumenty:
   array - wektor liczb ca�kowitych, w kt�rym b�dzie wyszukiwana warto��
   valueToFind - liczba ca�kowita, kt�ra ma zosta� odnaleziona w tablicy
 typ zwracany: int, indeks pierwszego wyst�pienia szukanej warto�ci lub -1, gdy nie znaleziono
 informacje: Funkcja przeszukuje tablic� za pomoc� algorytmu z wartownikiem.
             Wartownik jest tymczasowo dodawany na ko�cu tablicy, a nast�pnie usuwany.
 autor: EE-Informatyk.pl
 *****************************************************/
int searchWithSentinel(vector<int>& array, int valueToFind) {
    int n = array.size();
    array.push_back(valueToFind);

    int i = 0;
    while (array[i] != valueToFind) {
        i++;
    }

    array.pop_back();

    if (i == n) {
        return -1;
    }
    return i;
}

int main() {
    /******************************************************
     nazwa funkcji: main
     argumenty: brak
     typ zwracany: int, kod zako�czenia programu (0 oznacza poprawne zako�czenie)
     informacje: Funkcja g��wna programu, kt�ra testuje dzia�anie algorytmu.
                 Wype�nia tablic� pseudolosowymi liczbami, pobiera od u�ytkownika warto�� do wyszukania,
                 wywo�uje funkcj� wyszukuj�c� i wy�wietla wyniki dzia�ania.
     autor: EE-Informatyk.pl
     *****************************************************/

    const int ARRAY_SIZE = 50;
    vector<int> array;
    int valueToFind;

    fillArray(array, ARRAY_SIZE);
    cout << "Podaj wartosc do wyszukania: ";
    cin >> valueToFind;

    int index = searchWithSentinel(array, valueToFind);

    cout << "Zawartosc tablicy: ";
    for (size_t i = 0; i < array.size(); ++i) {
        cout << array[i];
        if (i < array.size() - 1) {
            cout << ", ";
        }
    }
    cout << endl;

    if (index == -1) {
        cout << "Nie znaleziono wartosci " << valueToFind << " w tablicy." << endl;
    }
    else {
        cout << "Wartosc " << valueToFind << " odnaleziono pod indeksem: " << index << endl;
    }

    return 0;
}
