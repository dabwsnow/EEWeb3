﻿using System;

class Program {
    /******************************************************
     nazwa funkcji: EuclideanAlgorithm
     argumenty: 
       a - int, liczba całkowita dodatnia, pierwsza liczba do obliczenia NWD
       b - int, liczba całkowita dodatnia, druga liczba do obliczenia NWD
     typ zwracany: int, największy wspólny dzielnik (NWD) liczb a i b
     informacje: Funkcja implementuje algorytm Euklidesa w pełnej zgodności ze schematem blokowym.
                 Funkcja nie wykonuje operacji wejścia-wyjścia.
     autor: EE-Informatyk.pl
    *****************************************************/
    static int EuclideanAlgorithm(int a, int b) {
        if (a <= 0 || b <= 0) {
            throw new ArgumentException("Liczby muszą być dodatnie.");
        }

        while (a != b) {
            if (a > b) {
                a = a - b;
            }
            else {
                b = b - a;
            }
        }
        return a;
    }

    /******************************************************
     nazwa funkcji: Main
     argumenty: brak
     typ zwracany: void, brak zwracanego wyniku
     informacje: Funkcja główna programu, która obsługuje interakcję z użytkownikiem.
                 Pobiera od użytkownika dwie liczby całkowite dodatnie, oblicza NWD za pomocą 
                 funkcji EuclideanAlgorithm, a następnie wyświetla wynik.
     autor: EE-Informatyk.pl
    *****************************************************/
    static void Main(string[] args) {
        Console.WriteLine("Program oblicza NWD dwóch liczb całkowitych dodatnich.");

        try {
            Console.Write("Podaj pierwszą liczbę (a): ");
            int a = int.Parse(Console.ReadLine());

            Console.Write("Podaj drugą liczbę (b): ");
            int b = int.Parse(Console.ReadLine());

            int nwd = EuclideanAlgorithm(a, b);
            Console.WriteLine($"Największy wspólny dzielnik (NWD) liczb {a} i {b} wynosi: {nwd}");
        }
        catch (FormatException) {
            Console.WriteLine("Błąd: Wprowadzono nieprawidłowe dane. Proszę wprowadzić liczby całkowite.");
        }
        catch (ArgumentException ex) {
            Console.WriteLine($"Błąd: {ex.Message}");
        }
    }
}