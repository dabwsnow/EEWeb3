def euclidean_algorithm(a, b):
    """
    ******************************************************
    nazwa funkcji: euclidean_algorithm
    argumenty: 
      a - int, liczba całkowita dodatnia, pierwsza liczba do obliczenia NWD
      b - int, liczba całkowita dodatnia, druga liczba do obliczenia NWD
    typ zwracany: int, największy wspólny dzielnik (NWD) liczb a i b
    informacje: Funkcja implementuje algorytm Euklidesa w pełnej zgodności ze schematem blokowym.
                Funkcja nie wykonuje operacji wejścia-wyjścia.
    autor: EE-Informatyk.pl
    ******************************************************
    """
    if a <= 0 or b <= 0:
        raise ValueError("Liczby muszą być dodatnie.")

    while a != b:
        if a > b:
            a = a - b
        else:
            b = b - a
    return a


def main():
    """
    ******************************************************
    nazwa funkcji: main
    argumenty: brak
    typ zwracany: None, brak zwracanego wyniku
    informacje: Funkcja główna programu, która obsługuje interakcję z użytkownikiem.
                Pobiera od użytkownika dwie liczby całkowite dodatnie, oblicza NWD za pomocą 
                funkcji euclidean_algorithm, a następnie wyświetla wynik.
    autor: EE-Informatyk.pl
    ******************************************************
    """
    print("Program oblicza NWD dwóch liczb całkowitych dodatnich.")

    try:
        a = int(input("Podaj pierwszą liczbę (a): "))
        b = int(input("Podaj drugą liczbę (b): "))

        nwd = euclidean_algorithm(a, b)
        print(f"Największy wspólny dzielnik (NWD) liczb {a} i {b} wynosi: {nwd}")
    except ValueError as e:
        print(f"Błąd: {e}")
    except Exception:
        print("Błąd: Wprowadzono nieprawidłowe dane. Proszę wprowadzić liczby całkowite.")


if __name__ == "__main__":
    main()