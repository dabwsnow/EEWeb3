#include <iostream>
#include <vector>

class Sorter {
private:
    std::vector<int> numbers;

    /********************************************************
    * nazwa funkcji: findMaxIndex
    * parametry wej�ciowe: start - indeks w tablicy, od kt�rego rozpoczyna si� wyszukiwanie
    * warto�� zwracana: indeks najwi�kszej warto�ci w tablicy w zakresie od start do ko�ca
    * autor: ee-informatyk.pl
    ********************************************************/
    int findMaxIndex(int start) {
        int maxIndex = start;
        for (size_t i = start + 1; i < numbers.size(); ++i) {
            if (numbers[i] > numbers[maxIndex]) {
                maxIndex = i;
            }
        }
        return maxIndex;
    }

public:
    Sorter() : numbers(10) {}

    /********************************************************
    * nazwa funkcji: readNumbers
    * parametry wej�ciowe: brak
    * warto�� zwracana: brak (wczytuje dane do tablicy `numbers` z klawiatury)
    * autor: ee-informatyk.pl
    ********************************************************/
    void readNumbers() {
        std::cout << "Podaj 10 liczb calkowitych do posortowania:" << std::endl;
        for (int& num : numbers) {
            std::cin >> num;
        }
    }

    /********************************************************
    * nazwa funkcji: sortDescending
    * parametry wej�ciowe: brak
    * warto�� zwracana: brak (sortuje tablic� `numbers` malej�co)
    * autor: ee-informatyk.pl
    ********************************************************/
    void sortDescending() {
        for (size_t i = 0; i < numbers.size() - 1; ++i) {
            int maxIndex = findMaxIndex(i);
            if (maxIndex != static_cast<int>(i)) {
                std::swap(numbers[i], numbers[maxIndex]);
            }
        }
    }

    /********************************************************
    * nazwa funkcji: displayNumbers
    * parametry wej�ciowe: brak
    * warto�� zwracana: brak (wy�wietla zawarto�� tablicy `numbers` na ekranie)
    * autor: ee-informatyk.pl
    ********************************************************/
    void displayNumbers() const {
        std::cout << "Posortowana tablica (malejaco):" << std::endl;
        for (const int& num : numbers) {
            std::cout << num << " ";
        }
        std::cout << std::endl;
    }
};

int main() {
    Sorter sorter;
    sorter.readNumbers();
    sorter.sortDescending();
    sorter.displayNumbers();
    return 0;
}
