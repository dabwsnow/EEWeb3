class Sorter:
    def __init__(self):
        self.numbers = [0] * 10

    """
    /********************************************************
    * nazwa funkcji: readNumbers
    * parametry wejściowe: brak
    * wartość zwracana: brak (wczytuje dane do tablicy `numbers` z klawiatury)
    * autor: ee-informatyk.pl
    ********************************************************/
    """
    def read_numbers(self):
        print("Podaj 10 liczb całkowitych do posortowania:")
        for i in range(len(self.numbers)):
            self.numbers[i] = int(input(f"Liczba {i + 1}: "))

    """
    /********************************************************
    * nazwa funkcji: sortDescending
    * parametry wejściowe: brak
    * wartość zwracana: brak (sortuje tablicę `numbers` malejąco)
    * autor: ee-informatyk.pl
    ********************************************************/
    """
    def sort_descending(self):
        for i in range(len(self.numbers) - 1):
            max_index = self.find_max_index(i)
            if max_index != i:
                self.numbers[i], self.numbers[max_index] = self.numbers[max_index], self.numbers[i]

    """
    /********************************************************
    * nazwa funkcji: findMaxIndex
    * parametry wejściowe: start - indeks w tablicy, od którego rozpoczyna się wyszukiwanie
    * wartość zwracana: indeks największej wartości w tablicy w zakresie od start do końca
    * autor: ee-informatyk.pl
    ********************************************************/
    """
    def find_max_index(self, start):
        max_index = start
        for i in range(start + 1, len(self.numbers)):
            if self.numbers[i] > self.numbers[max_index]:
                max_index = i
        return max_index
    """
    /********************************************************
    * nazwa funkcji: displayNumbers
    * parametry wejściowe: brak
    * wartość zwracana: brak (wyświetla zawartość tablicy `numbers` na ekranie)
    * autor: ee-informatyk.pl
    ********************************************************/
    """
    def display_numbers(self):
        print("Posortowana tablica (malejąco):")
        print(" ".join(map(str, self.numbers)))


if __name__ == "__main__":
    sorter = Sorter()
    sorter.read_numbers()
    sorter.sort_descending()
    sorter.display_numbers()