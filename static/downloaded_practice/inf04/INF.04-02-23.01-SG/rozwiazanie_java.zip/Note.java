/************************************************
 klasa: Note
 opis: Klasa reprezentujaca notatke
 pola: 
     - noteCounter: statyczny licznik utworzonych notatek
     - id: unikalny identyfikator notatki
     - title: tytul notatki
     - content: tresc notatki
 autor: ee-informatyk.pl 
************************************************/

public class Note {

    private static int noteCounter = 0; // Statyczny licznik notatek
    private int id; // Unikalny identyfikator notatki
    protected String title; // Tytul notatki
    protected String content; // Tresc notatki

    // Konstruktor
    public Note(String title, String content) {
        noteCounter++;
        this.id = noteCounter;
        this.title = title;
        this.content = content;
    }

    // Metoda wyswietlajaca tytul i tresc notatki
    public void displayNote() {
        System.out.println("Tytul: " + title + "\nTresc: " + content);
    }

    // Metoda diagnostyczna
    public void diagnosticInfo() {
        System.out.println("ID: " + id + "; Tytul: " + title + "; Tresc: " + content + "; Licznik: " + noteCounter);
    }

    public static void main(String[] args) {
        // Testowanie aplikacji
        System.out.println("Tworzenie pierwszej notatki...");
        Note firstNote = new Note("Zakupy", "Kupic chleb, mleko, jajka");
        firstNote.displayNote();
        firstNote.diagnosticInfo();

        System.out.println("\nTworzenie drugiej notatki...");
        Note secondNote = new Note("Praca domowa", "Napisac esej na temat historii Polski");
        secondNote.displayNote();
        secondNote.diagnosticInfo();
    }
}
