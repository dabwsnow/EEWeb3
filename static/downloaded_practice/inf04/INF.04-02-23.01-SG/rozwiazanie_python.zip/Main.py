# ************************************************
# klasa: Note
# opis: Klasa reprezentujaca notatke
# pola: 
#     - note_counter: statyczny licznik utworzonych notatek
#     - id: unikalny identyfikator notatki
#     - title: tytul notatki
#     - content: tresc notatki
# autor: ee-informatyk.pl
# ************************************************

class Note:
    note_counter = 0  # Statyczny licznik notatek

    def __init__(self, title, content):
        Note.note_counter += 1
        self.__id = Note.note_counter  # Unikalny identyfikator notatki
        self.title = title  # Tytul notatki
        self.content = content  # Tresc notatki

    def display_note(self):
        """Metoda wyswietlajaca tytul i tresc notatki."""
        print(f"Tytul: {self.title}\nTresc: {self.content}")

    def diagnostic_info(self):
        """Metoda diagnostyczna."""
        print(f"ID: {self.__id}; Tytul: {self.title}; Tresc: {self.content}; Licznik: {Note.note_counter}")


# Testowanie aplikacji
if __name__ == "__main__":
    print("Tworzenie pierwszej notatki...")
    first_note = Note("Zakupy", "Kupic chleb, mleko, jajka")
    first_note.display_note()
    first_note.diagnostic_info()

    print("\nTworzenie drugiej notatki...")
    second_note = Note("Praca domowa", "Napisac esej na temat historii Polski")
    second_note.display_note()
    second_note.diagnostic_info()
