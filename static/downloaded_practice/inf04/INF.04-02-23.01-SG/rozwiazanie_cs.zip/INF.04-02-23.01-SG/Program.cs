﻿using System;

/************************************************
 klasa: Note
 opis: Klasa reprezentująca notatkę
 pola: 
     - noteCounter: statyczny licznik utworzonych notatek
     - id: unikalny identyfikator notatki
     - title: tytuł notatki
     - content: treść notatki
 autor: ee-informatyk.pl 
************************************************/

public class Note
{
    private static int noteCounter = 0; // Statyczny licznik notatek
    private int id; // Unikalny identyfikator notatki
    protected string title; // Tytuł notatki
    protected string content; // Treść notatki

    // Konstruktor
    public Note(string title, string content)
    {
        noteCounter++;
        this.id = noteCounter;
        this.title = title;
        this.content = content;
    }

    // Metoda wyświetlająca tytuł i treść notatki
    public void DisplayNote()
    {
        Console.WriteLine($"Tytuł: {title}\nTreść: {content}");
    }

    // Metoda diagnostyczna
    public void DiagnosticInfo()
    {
        Console.WriteLine($"ID: {id}; Tytuł: {title}; Treść: {content}; Licznik: {noteCounter}");
    }
}

class Program
{
    static void Main(string[] args)
    {
        // Testowanie aplikacji
        Console.WriteLine("Tworzenie pierwszej notatki...");
        Note firstNote = new Note("Zakupy", "Kupić chleb, mleko, jajka");
        firstNote.DisplayNote();
        firstNote.DiagnosticInfo();

        Console.WriteLine("\nTworzenie drugiej notatki...");
        Note secondNote = new Note("Praca domowa", "Napisać esej na temat historii Polski");
        secondNote.DisplayNote();
        secondNote.DiagnosticInfo();

        Console.WriteLine("\nNaciśnij dowolny klawisz, aby zakończyć...");
        Console.ReadKey();
    }
}
