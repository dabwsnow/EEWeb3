/********************************************************
* nazwa klasy: Osoba
* pola: id - identyfikator osoby
*       imie - imię osoby
*       LiczbaInstancji - statyczne pole zliczające liczbę obiektów klasy
* konstruktory: Osoba() - bezparametrowy
*               Osoba(int id, String imie) - z parametrami
*               Osoba(Osoba osoba) - kopiujący
* metoda: powitanie - wyświetla powitanie
* autor: EE-Informatyk.pl
* ****************************************************/
public class Osoba {
    private int id;
    private String imie;
    public static int LiczbaInstancji = 0;

    public Osoba() {
        this.id = 0;
        this.imie = "";
        LiczbaInstancji++;
    }

    public Osoba(int id, String imie) {
        this.id = id;
        this.imie = imie;
        LiczbaInstancji++;
    }

    public Osoba(Osoba osoba) {
        this.id = osoba.id;
        this.imie = osoba.imie;
        LiczbaInstancji++;
    }

    public void powitanie(String argument) {
        if (imie.isEmpty()) {
            System.out.println("Brak danych");
        }
        else {
            System.out.println("Czesc " + argument + ", mam na imie " + imie);
        }
    }
}