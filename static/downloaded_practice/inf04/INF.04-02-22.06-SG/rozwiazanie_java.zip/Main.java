import java.util.Scanner;

public class Main {
    /********************************************************
    * nazwa funkcji: main
    * parametry wejściowe: brak
    * wartość zwracana: brak
    * autor: EE-Informatyk.pl
    * ****************************************************/
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Liczba zarejestrowanych osób to " + Osoba.LiczbaInstancji);

        Osoba osoba1 = new Osoba();
        osoba1.powitanie("Jan");

        System.out.print("Podaj id: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Podaj imie: ");
        String imie = scanner.nextLine();

        Osoba osoba2 = new Osoba(id, imie);
        osoba2.powitanie("Jan");

        Osoba osoba3 = new Osoba(osoba2);
        osoba3.powitanie("Jan");

        System.out.println("Liczba zarejestrowanych osob to " + Osoba.LiczbaInstancji);

        scanner.close();
    }
}