from Osoba import Osoba

if __name__ == "__main__":
    print(f"Liczba zarejestrowanych osób to {Osoba.LiczbaInstancji}")

    osoba1 = Osoba()
    osoba1.powitanie("Jan")

    id_input = int(input("Podaj id: "))
    imie_input = input("Podaj imię: ")
    osoba2 = Osoba(id_input, imie_input)
    osoba2.powitanie("Jan")

    osoba3 = Osoba.from_osoba(osoba2)
    osoba3.powitanie("Jan")

    print(f"Liczba zarejestrowanych osób to {Osoba.LiczbaInstancji}")