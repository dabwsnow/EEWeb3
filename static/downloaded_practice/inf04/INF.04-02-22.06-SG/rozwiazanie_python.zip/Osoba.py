"""
/********************************************************
* nazwa klasy: Osoba
* pola:
*   id (int) - identyfikator osoby
*   imie (str) - imię osoby
*   LiczbaInstancji (int) - statyczne pole zliczające obiekty
*
* konstruktory:
*   - bezparametrowy: ustawia id = 0 i imie = ""
*   - (metoda kopiująca) from_osoba: tworzy nowy obiekt na podstawie istniejącego
*
* metoda:
*   - powitanie(argument): wypisuje "Cześć <argument>, mam na imię <imie>"
*     lub "Brak danych" jeśli imie jest puste
*
* autor: EE-Informatyk.pl
* ****************************************************/
"""

class Osoba:
    LiczbaInstancji = 0

    def __init__(self, id=0, imie=""):
        """
        Konstruktor bezparametrowy oraz z parametrami (dzięki wartościom domyślnym).
        :param id: identyfikator osoby (int), domyślnie 0
        :param imie: imię osoby (str), domyślnie pusty string
        Wartość zwracana: brak
        Autor: EE-Informatyk.pl
        """
        self.__id = id
        self.__imie = imie
        Osoba.LiczbaInstancji += 1

    @classmethod
    def from_osoba(cls, osoba):
        """
        Konstruktor kopiujący. Tworzy nowy obiekt na podstawie istniejącego.
        :param osoba: instancja klasy Osoba, którą kopiujemy
        Wartość zwracana: nowa instancja klasy Osoba
        Autor: EE-Informatyk.pl
        """
        return cls(osoba.__id, osoba.__imie)

    def powitanie(self, argument):
        """
        Wypisuje powitanie.
        :param argument: imię osoby, do której się zwracamy (str)
        Wartość zwracana: brak
        Autor: EE-Informatyk.pl
        """
        if not self.__imie:
            print("Brak danych")
        else:
            print(f"Cześć {argument}, mam na imię {self.__imie}")