﻿using System;

namespace ForumSystem {
    public class Osoba {
        private int id;
        private string imie;

        public static int LiczbaInstancji {get; private set; } = 0;

        /********************************************************
        * nazwa funkcji: Osoba
        * parametry wejściowe: brak
        * wartość zwracana: brak
        * autor: EE-Informatyk.pl
        * ****************************************************/
        public Osoba() {
            id = 0;
            imie = string.Empty;
            LiczbaInstancji++;
        }

        /********************************************************
        * nazwa funkcji: Osoba
        * parametry wejściowe: id - identyfikator osoby, imie - imię osoby
        * wartość zwracana: brak
        * autor: EE-Informatyk.pl
        * ****************************************************/
        public Osoba(int id, string imie) {
            this.id = id;
            this.imie = imie;
            LiczbaInstancji++;
        }

        /********************************************************
        * nazwa funkcji: Osoba
        * parametry wejściowe: osoba - obiekt klasy Osoba
        * wartość zwracana: brak
        * autor: EE-Informatyk.pl
        * ****************************************************/
        public Osoba(Osoba osoba) {
            this.id = osoba.id;
            this.imie = osoba.imie;
            LiczbaInstancji++;
        }

        /********************************************************
        * nazwa funkcji: Powitanie
        * parametry wejściowe: argument - imię osoby, która wita
        * wartość zwracana: brak
        * autor: EE-Informatyk.pl
        * ****************************************************/
        public void Powitanie(string argument) {
            if (string.IsNullOrEmpty(imie)) {
                Console.WriteLine("Brak danych");
            }
            else {
                Console.WriteLine($"Cześć {argument}, mam na imię {imie}");
            }
        }
    }
}
