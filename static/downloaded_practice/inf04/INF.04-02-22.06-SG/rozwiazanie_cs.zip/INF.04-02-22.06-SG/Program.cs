﻿using System;

namespace ForumSystem {
    class Program {
        /********************************************************
        * nazwa funkcji: Main
        * parametry wejściowe: brak
        * wartość zwracana: brak
        * autor: EE-Informatyk.pl
        * ****************************************************/
        static void Main(string[] args) {
            Console.WriteLine($"Liczba zarejestrowanych osób to {Osoba.LiczbaInstancji}");

            Osoba osoba1 = new Osoba();
            osoba1.Powitanie("Jan");

            Console.WriteLine("Podaj id: ");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Podaj imię: ");
            string imie = Console.ReadLine();
            Osoba osoba2 = new Osoba(id, imie);
            osoba2.Powitanie("Jan");

            Osoba osoba3 = new Osoba(osoba2);
            osoba3.Powitanie("Jan");

            Console.WriteLine($"Liczba zarejestrowanych osób to {Osoba.LiczbaInstancji}");
        }
    }
}
