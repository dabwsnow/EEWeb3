﻿using System;

/// ************************************************
/// Klasa: StringTools
/// Opis: Klasa narzędziowa dla operacji na łańcuchach znaków.
/// Metody:
/// - CountVowels(string input) - Zwraca liczbę samogłosek w łańcuchu.
/// - RemoveDuplicates(string input) - Zwraca łańcuch bez powtórzeń sąsiadujących znaków.
/// Autor: EE-Informatyk.pl
/// ************************************************
public static class StringTools {
    public static int CountVowels(string input) {
        if (string.IsNullOrEmpty(input))
            return 0;

        string vowels = "aąeęiouóyAĄEĘIOUÓY";
        int count = 0;

        foreach (char c in input) {
            if (vowels.Contains(c))
                count++;
        }

        return count;
    }

    public static string RemoveDuplicates(string input) {
        if (string.IsNullOrEmpty(input))
            return string.Empty;

        char previousChar = input[0];
        string result = previousChar.ToString();

        for (int i = 1; i < input.Length; i++) {
            if (input[i] != previousChar) {
                result += input[i];
                previousChar = input[i];
            }
        }

        return result;
    }
}

class Program {
    static void Main(string[] args) {
        Console.WriteLine("Podaj łańcuch znaków:");
        string userInput = Console.ReadLine();

        int vowelCount = StringTools.CountVowels(userInput);
        string noDuplicates = StringTools.RemoveDuplicates(userInput);

        Console.WriteLine($"Liczba samogłosek: {vowelCount}");
        Console.WriteLine($"Łańcuch bez powtórzeń: {noDuplicates}");
    }
}
