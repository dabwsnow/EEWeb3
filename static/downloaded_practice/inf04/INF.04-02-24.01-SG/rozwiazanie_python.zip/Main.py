def count_vowels(input_str):
    if not input_str:
        return 0

    vowels = "aąeęiouóyAĄEĘIOUÓY"
    count = sum(1 for char in input_str if char in vowels)
    return count

def remove_duplicates(input_str):
    if not input_str:
        return ""

    result = [input_str[0]]
    for char in input_str[1:]:
        if char != result[-1]:
            result.append(char)

    return ''.join(result)

def main():
    input_str = input("Podaj łańcuch znaków: ")
    vowel_count = count_vowels(input_str)
    no_duplicates = remove_duplicates(input_str)
    print(f"Liczba samogłosek: {vowel_count}")
    print(f"Łańcuch bez powtórzeń: {no_duplicates}")

if __name__ == "__main__":
    main()
