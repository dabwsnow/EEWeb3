import java.nio.charset.StandardCharsets;
import java.util.Scanner;

/**
 * ************************************************
 * Klasa: Main
 * Opis: Klasa narzędziowa dla operacji na łańcuchach znaków.
 * Metody:
 * - countVowels(String input) - Zwraca liczbę samogłosek w łańcuchu.
 * - removeDuplicates(String input) - Zwraca łańcuch bez powtórzeń sąsiadujących znaków.
 * Autor: EE-Informatyk.pl
 * ************************************************
 */
public class Main {

    public static int countVowels(String input) {
        if (input == null || input.isEmpty()) {
            return 0;
        }

        String vowels = "aąeęiouóyAĄEĘIOUÓY";
        int count = 0;

        for (char c : input.toCharArray()) {
            if (vowels.indexOf(c) != -1) {
                count++;
            }
        }

        return count;
    }

    public static String removeDuplicates(String input) {
        if (input == null || input.isEmpty()) {
            return "";
        }

        StringBuilder result = new StringBuilder();
        char previousChar = input.charAt(0);
        result.append(previousChar);

        for (int i = 1; i < input.length(); i++) {
            char currentChar = input.charAt(i);
            if (currentChar != previousChar) {
                result.append(currentChar);
                previousChar = currentChar;
            }
        }

        return result.toString();
    }

    public static void main(String[] args) {
        System.out.println("Podaj łańcuch znaków:");
        Scanner scanner = new Scanner(System.in, StandardCharsets.UTF_8);
        String userInput = scanner.nextLine();

        int vowelCount = countVowels(userInput);
        String noDuplicates = removeDuplicates(userInput);

        System.out.println("Liczba samogłosek: " + vowelCount);
        System.out.println("Łańcuch bez powtórzeń: " + noDuplicates);

        scanner.close();
    }
}
