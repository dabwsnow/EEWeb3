/******************************************************
 nazwa klasy: Main
 pola: tytul - przechowuje tytul filmu
       liczbaWypozyczen - przechowuje liczbe wypozyczen filmu
 metody: setTytul(String nowyTytul), void – ustawia tytul filmu
         getTytul(), String – zwraca tytul filmu
         getLiczbaWypozyczen(), int – zwraca liczbe wypozyczen
         inkrementujLiczbaWypozyczen(), void – inkrementuje liczbe wypozyczen
 informacje: Klasa reprezentuje film w systemie wirtualnej wypozyczalni
 autor: EE-Informatyk.pl
*****************************************************/

public class Main {
    private String tytul;
    private int liczbaWypozyczen;

    public Main() {
        this.tytul = "";
        this.liczbaWypozyczen = 0;
    }

    public void setTytul(String nowyTytul) {
        if (nowyTytul.length() <= 20) {
            this.tytul = nowyTytul;
        }
        else {
            throw new IllegalArgumentException("Tytul moze miec maksymalnie 20 znakow.");
        }
    }

    public String getTytul() {
        return this.tytul;
    }

    public int getLiczbaWypozyczen() {
        return this.liczbaWypozyczen;
    }

    public void inkrementujLiczbaWypozyczen() {
        this.liczbaWypozyczen++;
    }

    public static void main(String[] args) {
        Main film = new Main();

        System.out.println("Poczatkowy tytul: " + film.getTytul());
        System.out.println("Poczatkowa liczba wypozyczen: " + film.getLiczbaWypozyczen());

        try {
            film.setTytul("Incepcja");
            System.out.println("Tytul po ustawieniu: " + film.getTytul());
        }
        catch (IllegalArgumentException e) {
            System.out.println("Blad: " + e.getMessage());
        }

        System.out.println("Liczba wypozyczen: " + film.getLiczbaWypozyczen());
        System.out.println("Liczba wypozyczen przed inkrementacja: " + film.getLiczbaWypozyczen());
        film.inkrementujLiczbaWypozyczen();
        System.out.println("Liczba wypozyczen po inkrementacji: " + film.getLiczbaWypozyczen());
    }
}
