"""
******************************************************
nazwa klasy: Film
pola: tytul - przechowuje tytul filmu
      liczba_wypozyczen - przechowuje liczbe wypozyczen filmu
metody: set_tytul(nowy_tytul), None – ustawia tytul filmu
        get_tytul(), str – zwraca tytul filmu
        get_liczba_wypozyczen(), int – zwraca liczbe wypozyczen
        inkrementuj_liczba_wypozyczen(), None – inkrementuje liczbe wypozyczen
informacje: Klasa reprezentuje film w systemie wirtualnej wypozyczalni
autor: EE-Informatyk.pl
******************************************************
"""

class Film:
    def __init__(self):
        self.__tytul = ""
        self.__liczba_wypozyczen = 0

    def set_tytul(self, nowy_tytul):
        if len(nowy_tytul) <= 20:
            self.__tytul = nowy_tytul
        else:
            raise ValueError("Tytul moze miec maksymalnie 20 znakow.")

    def get_tytul(self):
        return self.__tytul

    def get_liczba_wypozyczen(self):
        return self.__liczba_wypozyczen

    def inkrementuj_liczba_wypozyczen(self):
        self.__liczba_wypozyczen += 1


if __name__ == "__main__":
    film = Film()

    print("Poczatkowy tytul:", film.get_tytul())
    print("Poczatkowa liczba wypozyczen:", film.get_liczba_wypozyczen())

    try:
        film.set_tytul("Incepcja")
        print("Tytul po ustawieniu:", film.get_tytul())
    except ValueError as e:
        print("Blad:", e)

    print("Liczba wypozyczen:", film.get_liczba_wypozyczen())
    print("Liczba wypozyczen przed inkrementacja:", film.get_liczba_wypozyczen())
    film.inkrementuj_liczba_wypozyczen()
    print("Liczba wypozyczen po inkrementacji:", film.get_liczba_wypozyczen())
