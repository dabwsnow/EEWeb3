﻿/******************************************************
 nazwa klasy: Film
 pola: tytul - przechowuje tytuł filmu
        liczbaWypozyczen - przechowuje liczbę wypożyczeń filmu
 metody: UstawTytul(string nowyTytul), void – ustawia tytuł filmu
         PobierzTytul(), string – zwraca tytuł filmu
         PobierzLiczbaWypozyczen(), int – zwraca liczbę wypożyczeń
         InkrementujLiczbaWypozyczen(), void – inkrementuje liczbę wypożyczeń
 informacje: Klasa reprezentuje film w systemie wirtualnej wypożyczalni
 autor: EE-Informatyk.pl
*****************************************************/

using System;

namespace WypozyczalniaFilmow
{
    public class Film {
        private string tytul;
        private int liczbaWypozyczen;

        public Film()
        {
            tytul = string.Empty;
            liczbaWypozyczen = 0;
        }

        public void UstawTytul(string nowyTytul) {
            if (nowyTytul.Length <= 20) {
                tytul = nowyTytul;
            }
            else {
                throw new ArgumentException("Tytuł może mieć maksymalnie 20 znaków.");
            }
        }

        public string PobierzTytul() {
            return tytul;
        }

        public int PobierzLiczbaWypozyczen() {
            return liczbaWypozyczen;
        }

        public void InkrementujLiczbaWypozyczen() {
            liczbaWypozyczen++;
        }
    }

    class Program {
        static void Main(string[] args) {
            Film film = new Film();
            Console.WriteLine("Początkowy tytuł: " + film.PobierzTytul());
            Console.WriteLine("Początkowa liczba wypożyczeń: " + film.PobierzLiczbaWypozyczen());
            film.UstawTytul("Incepcja");
            Console.WriteLine("Tytuł po ustawieniu: " + film.PobierzTytul());
            Console.WriteLine("Liczba wypożyczeń: " + film.PobierzLiczbaWypozyczen());
            Console.WriteLine("Liczba wypożyczeń przed inkrementacją: " + film.PobierzLiczbaWypozyczen());
            film.InkrementujLiczbaWypozyczen();
            Console.WriteLine("Liczba wypożyczeń po inkrementacji: " + film.PobierzLiczbaWypozyczen());
        }
    }
}
