function ciag() {
    let a1 = parseInt(document.getElementById("a1").value);
    let r = parseInt(document.getElementById("r").value);
    let n = parseInt(document.getElementById("n").value);
    let wynik = document.getElementById("wynik");
    let res = "Ciąg arytmetyczny zawiera wyrazy: ";

    for (let a = a1; n > 0; n--) {
        res += a + ", ";
        a = a + r;
    }
    wynik.innerHTML = res;                    
}