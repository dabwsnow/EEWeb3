<?php
    if(isset($_POST["zespol"])) {
        $zespol = $_POST["zespol"];
        $dyspozytor = $_POST["dyspozytor"];
        $adres = $_POST["adres"];
        $czas = date("H:i:s ");

        $conn = new mysqli("localhost","root","","ratownictwo");

        $sql = "INSERT INTO zgloszenia (ratownicy_id, dyspozytorzy_id, adres, pilne, czas_zgloszenia) VALUES ($zespol, $dyspozytor, '$adres', 0, '$czas');";
        $result = $conn->query($sql);

        echo "Zgłoszenie zostało zarejestrowane";

        $conn -> close();
    }
?>