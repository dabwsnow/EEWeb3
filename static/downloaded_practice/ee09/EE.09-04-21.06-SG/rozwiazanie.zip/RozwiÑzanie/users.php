<?php
    $conn = new mysqli("localhost","root","","dane4");
?>

<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Panel administratora</title>
        <link rel="stylesheet" href="styl4.css">
    </head>
    <body>
        <header>
            <h3>Portal Społecznościowy - panel administratora</h3>
        </header>

        <div id="lewy">
            <h4>Użytkownicy</h4>
            <?php
                // Skrypt #1               
                $rok = date('Y');
                
                $sql = "SELECT id, imie, nazwisko, rok_urodzenia, zdjecie FROM osoby LIMIT 30;";
                $result = $conn->query($sql);

                while($row = $result -> fetch_array()) {
                    $wiek = $rok - $row[3];
                    echo "$row[0]. $row[1] $row[2], $wiek lat<br>";
                }
            ?>
            <a href="settings.html">Inne ustawienia</a>
        </div>

        <div id="prawy">
            <h4>Podaj id użytkownika</h4>
            <form action="users.php" method="post">
                <input type="number" name="id" id="id">
                <button type="submit">ZOBACZ</button>
            </form>
            <hr>
            <?php
                // Skrypt #2
                if(!empty($_POST["id"])) {
                    $id = $_POST["id"];

                    $sql = "SELECT osoby.imie, osoby.nazwisko, osoby.rok_urodzenia, osoby.opis, osoby.zdjecie, hobby.nazwa FROM osoby INNER JOIN hobby ON osoby.Hobby_id = hobby.id WHERE osoby.id = $id;";
                    $result = $conn->query($sql);

                    while($row = $result -> fetch_array()) {
                        echo "<h2>$id. $row[0] $row[1]</h2>";

                        echo "<img src='$row[4]' alt='$id'>";

                        echo "<p>Rok urodzenia: $row[2]</p>";
                        echo "<p>Opis: $row[3]</p>";
                        echo "<p>Hobby: $row[5]</p>";
                    }
                }
            ?>
        </div>

        <footer>
            Stronę wykonał: <a href="https://ee-informatyk.pl/" target="_blank" style="color: unset;text-decoration: none;">EE-Informatyk.pl</a>
        </footer>
    </body>
</html>

<?php
    $conn -> close();
?>