<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Prognoza pogody Poznań</title>
        <link rel="stylesheet" href="styl4.css">
    </head>
    <body>
        <div id="baner1">
            <p>maj, 2019r.</p>
        </div>

        <div id="baner2">
            <h2>Prognoza dla Poznania</h2>
        </div>

        <div id="baner3">
            <img src="logo.png" alt="prognoza">
        </div>

        <div id="lewy">
            <a href="kwerendy.txt">Kwerendy</a>
        </div>

        <div id="prawy">
            <img src="obraz.jpg" alt="Polska, Poznań">
        </div>

        <main>
            <table>
                <tr>
                    <th>Lp.</th>
                    <th>DATA</th>
                    <th>NOC - TEMPERATURA</th>
                    <th>DZIEŃ - TEMPERATURA</th>
                    <th>OPADY [mm/h]</th>
                    <th>CIŚNIENIE [hPa]</th>
                </tr>
                <?php
                    // Skrypt #1
                    $conn = new mysqli("localhost","root","","prognoza");

                    $sql = "SELECT * FROM pogoda WHERE miasta_id = 2 ORDER BY data_prognozy DESC;";
                    $result = $conn->query($sql);
                    
                    while($row = $result -> fetch_array()) {
                        echo "<tr>";
                            echo "<td>".$row["id"]."</td>";
                            echo "<td>".$row["data_prognozy"]."</td>";
                            echo "<td>".$row["temperatura_noc"]."</td>";
                            echo "<td>".$row["temperatura_dzien"]."</td>";
                            echo "<td>".$row["opady"]."</td>";
                            echo "<td>".$row["cisnienie"]."</td>";
                        echo "</tr>";
                    }
                    
                    $conn -> close();
                ?>
            </table>
        </main>

        <footer>
            <p>Stronę wykonał: <a href="https://ee-informatyk.pl/" target="_blank" style="color: unset;text-decoration: none;">EE-Informatyk.pl</a></p>
        </footer>
    </body>
</html>