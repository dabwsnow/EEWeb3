function oblicz() {
    var rodzajPaliwa = document.getElementById('rodzaj').value;
    var litryPaliwa = document.getElementById('litry').value;
    var cenaPaliwa;

    if (rodzajPaliwa == 1) {
        cenaPaliwa = 4;
    }
    else if (rodzajPaliwa == 2) {
        cenaPaliwa = 3.5;
    }
    else {
        cenaPaliwa = 0;
    }

    document.getElementById('wynik').innerHTML = 'Koszt paliwa: ' + (cenaPaliwa * litryPaliwa) + ' zł';
}