<?php
    if(!empty($_POST["karetka"]) && !empty($_POST["ratownik1"]) && !empty($_POST["ratownik2"]) && !empty($_POST["ratownik3"])) {
        $karetka = $_POST["karetka"];
        $ratownik1 = $_POST["ratownik1"];
        $ratownik2 = $_POST["ratownik2"];
        $ratownik3 = $_POST["ratownik3"];

        $conn = new mysqli("localhost","root","","ee09");

        $sql = "INSERT INTO ratownicy VALUES (NULL, $karetka, '$ratownik1', '$ratownik2', '$ratownik3');";
        $result = $conn->query($sql);

        $conn -> close();

        echo "Nowy zespół medyczny został dodany";
    }
?>