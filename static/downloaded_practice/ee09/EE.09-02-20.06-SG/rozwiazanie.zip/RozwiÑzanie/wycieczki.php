<?php
    $conn = new mysqli("localhost","root","","egzamin3");
?>

<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Wycieczki i urlopy</title>
        <link rel="stylesheet" href="styl3.css">
    </head>
    <body>
        <header>
            <h1>BIURO PODRÓŻY</h1>
        </header>

        <div id="lewy">
            <h2>KONTAKT</h2>
            <a href="mailto:biuro@wycieczki.pl">napisz do nas</a>
            <p>telefon: 555666777</p>
        </div>

        <div id="srodkowy">
            <h2>GALERIA</h2>
            <?php
                // Skrypt #1
                $sql = "SELECT nazwaPliku, podpis FROM zdjecia ORDER BY podpis ASC;";
                $result = $conn->query($sql);

                while($row = $result -> fetch_array()) {
                    echo "<img src='".$row["nazwaPliku"]."' alt='".$row["podpis"]."'>";
                }
            ?>
        </div>

        <div id="prawy">
            <h2>PROMOCJE</h2>
            <table>
                <tr>
                    <td>Jesień</td>
                    <td>Grupa 4+</td>
                    <td>Grupa 10+</td>
                </tr>
                <tr>
                    <td>5%</td>
                    <td>10%</td>
                    <td>15%</td>
                </tr>
            </table>
        </div>

        <main>
            <h2>LISTA WYCIECZEK</h2>
            <?php
                // Skrypt #2
                $sql = "SELECT id, dataWyjazdu, cel, cena FROM wycieczki WHERE dostepna = 1;";
                $result = $conn->query($sql);

                while($row = $result -> fetch_array()) {
                    echo $row["id"].". ".$row["dataWyjazdu"].", ".$row["cel"].", cena: ".$row["cena"]."<br>";
                }
            ?>
        </main>

        <footer>
            <p>Stronę wykonał: <a href="https://ee-informatyk.pl/" target="_blank" style="color: unset;text-decoration: none;">EE-Informatyk.pl</a></p>
        </footer>
    </body>
</html>

<?php
    $conn -> close();
?>