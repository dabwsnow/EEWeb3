<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Lista przyjaciół</title>
        <link rel="stylesheet" href="styl.css">
    </head>
    <body>
        <header>
            <h1>Portal Społecznościowy - moje konto</h1>
        </header>

        <main>
            <h2>Moje zainteresowania</h2>
            <ul>
                <li>muzyka</li>
                <li>film</li>
                <li>komputery</li>
            </ul>
            <h2>Moi znajomi</h2>
            <?php
                // Skrypt #1
                $conn = new mysqli("localhost","root","","dane");

                $sql = "SELECT imie, nazwisko, opis, zdjecie FROM osoby WHERE Hobby_id IN (1, 2 ,6);";
                $result = $conn->query($sql);

                while($row = $result -> fetch_array()) {
                    echo "<div class='zdjecie'>";
                        echo "<img src='$row[3]' alt='przyjaciel'>";
                    echo "</div>";

                    echo "<div class='opis'>";
                        echo "<h3>$row[0] $row[1]</h3>";
                        echo "<p>Ostani wpis: $row[2]</p>";
                    echo "</div>";
                    
                    echo "<hr>";
                }

                $conn -> close();
            ?>
        </main>

        <div id="stopka1">
            Stronę wykonał: <a href="https://ee-informatyk.pl/" target="_blank" style="color: unset;text-decoration: none;">EE-Informatyk.pl</a>
        </div>

        <div id="stopka2">
            <a href="mailto:ja@portal.pl">napisz do mnie</a>
        </div>
    </body>
</html>