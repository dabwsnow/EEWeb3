<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Klub wędkowania</title>
        <link rel="stylesheet" href="styl2.css">
    </head>
    <body>
        <header>
            <h2>Wędkuj z nami!</h2>
        </header>

        <div id="lewy">
            <img src="ryba2.jpg" alt="Szczupak">
        </div>

        <div id="prawy">
            <h3>Ryby spokojnego żeru (białe)</h3>
            <?php
                // Skrypt #1
                $conn = new mysqli("localhost","root","","wedkowanie");

                $sql = "SELECT id, nazwa, wystepowanie FROM ryby WHERE styl_zycia = 2;";
                $result = $conn->query($sql);

                while($row = $result -> fetch_array()) {
                    echo $row["id"].". ".$row["nazwa"].", występuje w: ".$row["wystepowanie"]."<br>";
                }

                $conn -> close();
            ?>
            <ol>
                <li><a href="https://wedkuje.pl/" target="_blank">Odwiedź także</a></li>
                <li><a href="http://www.pzw.org.pl/" target="_blank">Polski Związek Wędkarski</a></li>
            </ol>
        </div>

        <footer>
            <p>Stronę wykonał: <a href="https://ee-informatyk.pl/" target="_blank" style="color: unset;text-decoration: none;">EE-Informatyk.pl</a></p>
        </footer>
    </body>
</html>