function oblicz() {
    let dystans = document.getElementById('dystans').value;
    let spalanie = document.getElementById('spalanie').value;
    let wynik = dystans / 100 * spalanie;
    document.getElementById('wynik').innerHTML = 'Potrzebujesz: ' + wynik + ' litrów paliwa';
}