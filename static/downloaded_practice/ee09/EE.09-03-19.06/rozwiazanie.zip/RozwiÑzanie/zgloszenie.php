<?php
    if(isset($_POST["lowisko"]) && isset($_POST["data"]) && isset($_POST["sedzia"])) {
        $lowisko = $_POST["lowisko"];
        $data = $_POST["data"];
        $sedzia = $_POST["sedzia"];

        $conn = new mysqli("localhost","root","","wedkarstwo");

        $sql = "INSERT INTO zawody_wedkarskie (Karty_wedkarskie_id, Lowisko_id, data_zawodow, sedzia) VALUES (0, $lowisko, '$data', '$sedzia');";
        $result = $conn->query($sql);

        $conn -> close();

        echo "Nowe zawody wędkarskie zostały dodane";
    }
?>